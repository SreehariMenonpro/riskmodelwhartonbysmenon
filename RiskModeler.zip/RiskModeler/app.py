import streamlit as st
import sys
import os

# Add modules to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'modules'))
sys.path.append(os.path.join(os.path.dirname(__file__), 'utils'))

from modules import data_input, var_calculator, altman_zscore, scenario_analysis, stress_testing, volatility_sizing, risk_dashboard, report_generator

def main():
    st.set_page_config(
        page_title="Wharton Risk Analysis Model",
        page_icon="📊",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    st.title("🏦 Wharton Competition Risk Analysis Model")
    st.markdown("### Comprehensive Risk Assessment & Portfolio Management Tool")
    
    # Initialize session state
    if 'portfolio_data' not in st.session_state:
        st.session_state.portfolio_data = None
    if 'company_financials' not in st.session_state:
        st.session_state.company_financials = None
    if 'market_data' not in st.session_state:
        st.session_state.market_data = None
    
    # Sidebar navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.selectbox(
        "Choose Analysis Module",
        [
            "🏠 Risk Dashboard",
            "📊 Data Input",
            "📈 Value at Risk (VaR)",
            "💰 Altman Z-Score",
            "🌊 Scenario Analysis",
            "⚡ Stress Testing",
            "🎯 Volatility Sizing",
            "📋 Risk Report"
        ]
    )
    
    # Display selected page
    if page == "🏠 Risk Dashboard":
        risk_dashboard.show_dashboard()
    elif page == "📊 Data Input":
        data_input.show_data_input()
    elif page == "📈 Value at Risk (VaR)":
        var_calculator.show_var_calculator()
    elif page == "💰 Altman Z-Score":
        altman_zscore.show_altman_zscore()
    elif page == "🌊 Scenario Analysis":
        scenario_analysis.show_scenario_analysis()
    elif page == "⚡ Stress Testing":
        stress_testing.show_stress_testing()
    elif page == "🎯 Volatility Sizing":
        volatility_sizing.show_volatility_sizing()
    elif page == "📋 Risk Report":
        report_generator.show_report_generator()

if __name__ == "__main__":
    main()
