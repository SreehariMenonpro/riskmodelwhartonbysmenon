import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px

def calculate_altman_zscore(financial_data):
    """Calculate Altman Z-Score using the standard formula"""
    try:
        # Extract financial metrics
        working_capital = financial_data.get('working_capital', 0)
        total_assets = financial_data.get('total_assets', 1)  # Avoid division by zero
        retained_earnings = financial_data.get('retained_earnings', 0)
        ebit = financial_data.get('ebit', 0)
        market_cap = financial_data.get('market_cap', 0)
        total_liabilities = financial_data.get('total_liabilities', 1)  # Avoid division by zero
        revenue = financial_data.get('revenue', 0)
        
        # Calculate ratios
        x1 = working_capital / total_assets if total_assets > 0 else 0
        x2 = retained_earnings / total_assets if total_assets > 0 else 0
        x3 = ebit / total_assets if total_assets > 0 else 0
        x4 = market_cap / total_liabilities if total_liabilities > 0 else 0
        x5 = revenue / total_assets if total_assets > 0 else 0
        
        # Altman Z-Score formula
        z_score = 1.2 * x1 + 1.4 * x2 + 3.3 * x3 + 0.6 * x4 + 1.0 * x5
        
        return z_score, {
            'Working Capital / Total Assets': x1,
            'Retained Earnings / Total Assets': x2,
            'EBIT / Total Assets': x3,
            'Market Cap / Total Liabilities': x4,
            'Revenue / Total Assets': x5
        }
    except Exception as e:
        st.error(f"Error calculating Z-Score: {e}")
        return None, None

def interpret_zscore(z_score):
    """Interpret the Z-Score result"""
    if z_score >= 2.99:
        return "Safe Zone", "Low bankruptcy risk", "green"
    elif z_score >= 1.8:
        return "Grey Zone", "Moderate bankruptcy risk", "orange"
    else:
        return "Distress Zone", "High bankruptcy risk", "red"

def show_altman_zscore():
    st.header("💰 Altman Z-Score Analysis")
    
    # Check if financial data is available
    if st.session_state.company_financials is None:
        st.warning("Please load company financial data first in the Data Input section.")
        return
    
    st.subheader("Bankruptcy Prediction Model")
    st.write("""
    The Altman Z-Score is a credit-strength test that gauges a company's likelihood of bankruptcy.
    The formula combines five financial ratios weighted by coefficients derived from statistical analysis.
    """)
    
    # Display financial data summary
    financial_data = st.session_state.company_financials
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Company Financial Summary**")
        st.write(f"**Symbol:** {financial_data.get('symbol', 'N/A')}")
        st.write(f"**Total Assets:** ${financial_data.get('total_assets', 0):,.0f}")
        st.write(f"**Total Revenue:** ${financial_data.get('revenue', 0):,.0f}")
        st.write(f"**Market Cap:** ${financial_data.get('market_cap', 0):,.0f}")
    
    with col2:
        st.write("**Key Ratios Input**")
        st.write(f"**Working Capital:** ${financial_data.get('working_capital', 0):,.0f}")
        st.write(f"**Retained Earnings:** ${financial_data.get('retained_earnings', 0):,.0f}")
        st.write(f"**EBIT:** ${financial_data.get('ebit', 0):,.0f}")
    
    # Calculate Z-Score
    z_score, ratios = calculate_altman_zscore(financial_data)
    
    if z_score is not None:
        # Display Z-Score result
        zone, interpretation, color = interpret_zscore(z_score)
        
        st.markdown("---")
        st.subheader("Z-Score Results")
        
        # Main Z-Score display
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Altman Z-Score", f"{z_score:.2f}")
        
        with col2:
            if color == "green":
                st.success(f"**{zone}**")
            elif color == "orange":
                st.warning(f"**{zone}**")
            else:
                st.error(f"**{zone}**")
        
        with col3:
            st.write(f"**Risk Level:** {interpretation}")
        
        # Z-Score gauge chart
        fig_gauge = go.Figure(go.Indicator(
            mode = "gauge+number+delta",
            value = z_score,
            domain = {'x': [0, 1], 'y': [0, 1]},
            title = {'text': "Altman Z-Score"},
            delta = {'reference': 2.99},
            gauge = {
                'axis': {'range': [None, 5]},
                'bar': {'color': color},
                'steps': [
                    {'range': [0, 1.8], 'color': "red"},
                    {'range': [1.8, 2.99], 'color': "orange"},
                    {'range': [2.99, 5], 'color': "green"}
                ],
                'threshold': {
                    'line': {'color': "black", 'width': 4},
                    'thickness': 0.75,
                    'value': z_score
                }
            }
        ))
        
        fig_gauge.update_layout(height=400)
        st.plotly_chart(fig_gauge, use_container_width=True)
        
        # Ratio breakdown
        st.subheader("Ratio Analysis")
        
        ratio_df = pd.DataFrame({
            'Component': list(ratios.keys()),
            'Value': list(ratios.values()),
            'Weight': [1.2, 1.4, 3.3, 0.6, 1.0],
            'Weighted Value': [ratios[key] * weight for key, weight in zip(ratios.keys(), [1.2, 1.4, 3.3, 0.6, 1.0])]
        })
        
        # Display ratio table
        st.dataframe(ratio_df, use_container_width=True)
        
        # Ratio contribution chart
        fig_ratios = px.bar(
            ratio_df,
            x='Component',
            y='Weighted Value',
            title='Z-Score Component Contributions',
            color='Weighted Value',
            color_continuous_scale='RdYlGn'
        )
        fig_ratios.update_layout(height=400, xaxis_tickangle=-45)
        st.plotly_chart(fig_ratios, use_container_width=True)
        
        # Industry benchmarking
        st.subheader("Industry Benchmarking")
        
        # Sample industry benchmarks (in practice, these would come from a database)
        industry_benchmarks = {
            'Technology': {'avg_zscore': 3.2, 'safe_pct': 75, 'distress_pct': 10},
            'Manufacturing': {'avg_zscore': 2.8, 'safe_pct': 60, 'distress_pct': 20},
            'Retail': {'avg_zscore': 2.1, 'safe_pct': 45, 'distress_pct': 35},
            'Energy': {'avg_zscore': 1.9, 'safe_pct': 40, 'distress_pct': 40},
            'Real Estate': {'avg_zscore': 1.7, 'safe_pct': 35, 'distress_pct': 45}
        }
        
        selected_industry = st.selectbox(
            "Select industry for comparison:",
            list(industry_benchmarks.keys())
        )
        
        if selected_industry:
            benchmark = industry_benchmarks[selected_industry]
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                diff = z_score - benchmark['avg_zscore']
                st.metric(
                    "vs Industry Average",
                    f"{diff:+.2f}",
                    f"Industry: {benchmark['avg_zscore']:.2f}"
                )
            
            with col2:
                st.metric(
                    "Industry Safe %",
                    f"{benchmark['safe_pct']}%"
                )
            
            with col3:
                st.metric(
                    "Industry Distress %",
                    f"{benchmark['distress_pct']}%"
                )
        
        # Historical trend (simulated)
        st.subheader("Historical Z-Score Trend")
        
        # Generate simulated historical data
        periods = 12
        base_score = z_score
        historical_scores = []
        dates = pd.date_range(end=pd.Timestamp.now(), periods=periods, freq='M')
        
        for i in range(periods):
            # Add some realistic variation
            variation = np.random.normal(0, 0.3)
            trend = -0.1 * (periods - i) / periods  # Slight downward trend
            score = base_score + variation + trend
            historical_scores.append(max(0, score))  # Ensure non-negative
        
        trend_df = pd.DataFrame({
            'Date': dates,
            'Z_Score': historical_scores
        })
        
        fig_trend = px.line(
            trend_df,
            x='Date',
            y='Z_Score',
            title='Historical Z-Score Trend',
            markers=True
        )
        
        # Add zone lines
        fig_trend.add_hline(y=2.99, line_dash="dash", line_color="green", 
                           annotation_text="Safe Zone")
        fig_trend.add_hline(y=1.8, line_dash="dash", line_color="orange", 
                           annotation_text="Grey Zone")
        
        fig_trend.update_layout(height=400)
        st.plotly_chart(fig_trend, use_container_width=True)
        
        # Risk recommendations
        st.subheader("Risk Management Recommendations")
        
        if z_score >= 2.99:
            st.success("**Low Risk - Maintain Current Strategy**")
            st.write("- Company shows strong financial health")
            st.write("- Consider growth opportunities")
            st.write("- Monitor for any declining trends")
        elif z_score >= 1.8:
            st.warning("**Moderate Risk - Enhanced Monitoring**")
            st.write("- Implement closer financial monitoring")
            st.write("- Review credit facilities and cash flow")
            st.write("- Consider debt reduction strategies")
            st.write("- Diversify customer base and revenue streams")
        else:
            st.error("**High Risk - Immediate Action Required**")
            st.write("- Urgent financial restructuring may be needed")
            st.write("- Seek professional financial advisory")
            st.write("- Consider asset sales or emergency funding")
            st.write("- Implement strict cost controls")
        
        # Store results for use in other modules
        st.session_state.zscore_results = {
            'z_score': z_score,
            'zone': zone,
            'interpretation': interpretation,
            'ratios': ratios,
            'company_symbol': financial_data.get('symbol', 'Unknown')
        }
    
    else:
        st.error("Unable to calculate Z-Score. Please check your financial data.")
