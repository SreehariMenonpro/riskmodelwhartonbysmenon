import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from scipy import stats
from utils.risk_calculations import calculate_portfolio_returns

def calculate_position_sizing(target_volatility, asset_volatilities, correlations, current_weights):
    """Calculate optimal position sizes based on volatility targeting"""
    try:
        # Convert to numpy arrays
        vols = np.array(list(asset_volatilities.values()))
        weights = np.array(list(current_weights.values()))
        
        # Create correlation matrix (simplified - using average correlation)
        n_assets = len(vols)
        avg_correlation = np.mean([v for v in correlations.values() if v != 1.0]) if correlations else 0.3
        
        corr_matrix = np.full((n_assets, n_assets), avg_correlation)
        np.fill_diagonal(corr_matrix, 1.0)
        
        # Calculate portfolio volatility
        cov_matrix = np.outer(vols, vols) * corr_matrix
        portfolio_vol = np.sqrt(np.dot(weights, np.dot(cov_matrix, weights)))
        
        # Calculate volatility contribution by asset
        marginal_vol = np.dot(cov_matrix, weights) / portfolio_vol
        vol_contribution = weights * marginal_vol
        
        # Risk parity weights (equal volatility contribution)
        risk_parity_weights = (1 / vols) / np.sum(1 / vols)
        
        # Volatility targeting scaling
        vol_target_scalar = target_volatility / portfolio_vol
        vol_target_weights = weights * vol_target_scalar
        
        # Normalize if weights exceed 1
        if np.sum(vol_target_weights) > 1:
            vol_target_weights = vol_target_weights / np.sum(vol_target_weights)
        
        return {
            'current_portfolio_vol': portfolio_vol,
            'vol_contributions': dict(zip(asset_volatilities.keys(), vol_contribution)),
            'risk_parity_weights': dict(zip(asset_volatilities.keys(), risk_parity_weights)),
            'vol_target_weights': dict(zip(asset_volatilities.keys(), vol_target_weights)),
            'vol_target_scalar': vol_target_scalar
        }
    
    except Exception as e:
        st.error(f"Error in position sizing calculation: {e}")
        return None

def calculate_kelly_criterion(expected_returns, volatilities, win_rate=None):
    """Calculate Kelly Criterion optimal position sizes"""
    kelly_fractions = {}
    
    for symbol in expected_returns.keys():
        if symbol in volatilities:
            expected_return = expected_returns[symbol]
            volatility = volatilities[symbol]
            
            if volatility > 0:
                # Simplified Kelly: f = (bp - q) / b where b = expected return/risk, p = win rate, q = lose rate
                if win_rate is None:
                    # Estimate win rate from expected return (simplified)
                    win_rate = 0.55 if expected_return > 0 else 0.45
                
                sharpe_ratio = expected_return / volatility
                kelly_fraction = min(0.25, max(0, sharpe_ratio * win_rate))  # Cap at 25%
                kelly_fractions[symbol] = kelly_fraction
    
    return kelly_fractions

def calculate_var_based_sizing(var_estimates, portfolio_value, max_position_risk=0.02):
    """Calculate position sizes based on VaR estimates"""
    var_based_sizes = {}
    
    for symbol, var_pct in var_estimates.items():
        if var_pct < 0:  # VaR should be negative (loss)
            # Calculate position size that limits loss to max_position_risk of portfolio
            max_loss = portfolio_value * max_position_risk
            position_var = abs(var_pct)
            
            if position_var > 0:
                position_size = max_loss / (portfolio_value * position_var)
                var_based_sizes[symbol] = min(position_size, 0.2)  # Cap at 20%
            else:
                var_based_sizes[symbol] = 0.05  # Default small position
    
    return var_based_sizes

def show_volatility_sizing():
    st.header("🎯 Volatility Sizing & Position Management")
    
    # Check if required data is available
    if st.session_state.portfolio_data is None or st.session_state.market_data is None:
        st.warning("Please load portfolio and market data first in the Data Input section.")
        return
    
    st.subheader("Position Risk Management")
    st.write("""
    Optimize position sizes based on volatility targeting, risk parity, and advanced sizing methodologies.
    This analysis helps determine optimal portfolio weights for risk-adjusted returns.
    """)
    
    tab1, tab2, tab3, tab4 = st.tabs([
        "Volatility Analysis", 
        "Position Sizing Models", 
        "Risk-Based Sizing", 
        "Portfolio Optimization"
    ])
    
    with tab1:
        st.subheader("Portfolio Volatility Analysis")
        
        # Calculate individual asset volatilities
        try:
            portfolio_returns = calculate_portfolio_returns(
                st.session_state.portfolio_data, 
                st.session_state.market_data
            )
            
            asset_volatilities = {}
            asset_returns = {}
            correlations = {}
            
            # Calculate volatilities for each asset
            for _, holding in st.session_state.portfolio_data.iterrows():
                symbol = holding['Symbol']
                
                if symbol in st.session_state.market_data:
                    price_data = st.session_state.market_data[symbol]
                    returns = price_data['Close'].pct_change().dropna()
                    
                    if len(returns) > 10:  # Ensure sufficient data
                        volatility = returns.std() * np.sqrt(252)  # Annualized
                        asset_volatilities[symbol] = volatility
                        asset_returns[symbol] = returns.mean() * 252  # Annualized
                        
                        # Calculate correlation with market (S&P 500)
                        if '^GSPC' in st.session_state.market_data:
                            market_returns = st.session_state.market_data['^GSPC']['Close'].pct_change().dropna()
                            # Align returns
                            aligned_returns = returns.reindex(market_returns.index).dropna()
                            aligned_market = market_returns.reindex(aligned_returns.index).dropna()
                            
                            if len(aligned_returns) > 10 and len(aligned_market) > 10:
                                correlation = np.corrcoef(aligned_returns, aligned_market)[0, 1]
                                correlations[symbol] = correlation if not np.isnan(correlation) else 0
            
            if asset_volatilities:
                # Display volatility metrics
                vol_df = pd.DataFrame({
                    'Symbol': list(asset_volatilities.keys()),
                    'Annualized Volatility (%)': [v*100 for v in asset_volatilities.values()],
                    'Expected Return (%)': [asset_returns.get(s, 0)*100 for s in asset_volatilities.keys()],
                    'Market Correlation': [correlations.get(s, 0) for s in asset_volatilities.keys()],
                    'Sharpe Ratio': [asset_returns.get(s, 0)/v if v > 0 else 0 for s, v in asset_volatilities.items()]
                })
                
                st.dataframe(vol_df, use_container_width=True)
                
                # Volatility chart
                fig_vol = px.bar(
                    vol_df,
                    x='Symbol',
                    y='Annualized Volatility (%)',
                    title='Asset Volatility Comparison',
                    color='Annualized Volatility (%)',
                    color_continuous_scale='RdYlGn_r'
                )
                fig_vol.update_layout(height=400)
                st.plotly_chart(fig_vol, use_container_width=True)
                
                # Risk-Return scatter
                fig_scatter = px.scatter(
                    vol_df,
                    x='Annualized Volatility (%)',
                    y='Expected Return (%)',
                    text='Symbol',
                    title='Risk-Return Profile',
                    color='Sharpe Ratio',
                    size='Market Correlation'
                )
                fig_scatter.update_traces(textposition="top center")
                fig_scatter.update_layout(height=500)
                st.plotly_chart(fig_scatter, use_container_width=True)
                
                # Store calculated metrics
                st.session_state.asset_metrics = {
                    'volatilities': asset_volatilities,
                    'returns': asset_returns,
                    'correlations': correlations
                }
        
        except Exception as e:
            st.error(f"Error calculating volatility metrics: {e}")
    
    with tab2:
        st.subheader("Position Sizing Models")
        
        if 'asset_metrics' in st.session_state:
            asset_volatilities = st.session_state.asset_metrics['volatilities']
            asset_returns = st.session_state.asset_metrics['returns']
            correlations = st.session_state.asset_metrics['correlations']
            
            # Current portfolio weights
            current_weights = {}
            total_weight = 0
            
            for _, holding in st.session_state.portfolio_data.iterrows():
                symbol = holding['Symbol']
                weight = holding.get('Weight', 0)
                current_weights[symbol] = weight
                total_weight += weight
            
            # Normalize weights
            if total_weight > 0:
                current_weights = {k: v/total_weight for k, v in current_weights.items()}
            
            # Configuration
            col1, col2 = st.columns(2)
            
            with col1:
                target_volatility = st.slider("Target Portfolio Volatility (%)", 5, 30, 15) / 100
                max_position_size = st.slider("Maximum Position Size (%)", 5, 50, 25) / 100
            
            with col2:
                rebalance_threshold = st.slider("Rebalancing Threshold (%)", 1, 10, 5) / 100
                risk_free_rate = st.number_input("Risk-free Rate (%)", 0.0, 10.0, 2.5) / 100
            
            if st.button("Calculate Position Sizes"):
                with st.spinner("Calculating optimal position sizes..."):
                    # Calculate position sizing
                    sizing_results = calculate_position_sizing(
                        target_volatility, 
                        asset_volatilities, 
                        correlations, 
                        current_weights
                    )
                    
                    if sizing_results:
                        # Kelly Criterion sizing
                        excess_returns = {k: v - risk_free_rate for k, v in asset_returns.items()}
                        kelly_sizes = calculate_kelly_criterion(excess_returns, asset_volatilities)
                        
                        # VaR-based sizing (simplified)
                        var_estimates = {}
                        for symbol in asset_volatilities.keys():
                            # Estimate 5% VaR using normal distribution
                            vol = asset_volatilities[symbol]
                            expected_return = asset_returns.get(symbol, 0)
                            var_5pct = expected_return - 1.645 * vol  # 5% VaR
                            var_estimates[symbol] = var_5pct
                        
                        var_based_sizes = calculate_var_based_sizing(var_estimates, 1000000)
                        
                        # Create comparison dataframe
                        comparison_df = pd.DataFrame({
                            'Symbol': list(current_weights.keys()),
                            'Current Weight (%)': [current_weights.get(s, 0)*100 for s in current_weights.keys()],
                            'Risk Parity (%)': [sizing_results['risk_parity_weights'].get(s, 0)*100 for s in current_weights.keys()],
                            'Vol Target (%)': [sizing_results['vol_target_weights'].get(s, 0)*100 for s in current_weights.keys()],
                            'Kelly Criterion (%)': [kelly_sizes.get(s, 0)*100 for s in current_weights.keys()],
                            'VaR-Based (%)': [var_based_sizes.get(s, 0)*100 for s in current_weights.keys()]
                        })
                        
                        st.subheader("Position Sizing Comparison")
                        st.dataframe(comparison_df, use_container_width=True)
                        
                        # Visualization
                        fig_comparison = go.Figure()
                        
                        methods = ['Current Weight (%)', 'Risk Parity (%)', 'Vol Target (%)', 'Kelly Criterion (%)', 'VaR-Based (%)']
                        colors = ['blue', 'green', 'orange', 'red', 'purple']
                        
                        for i, method in enumerate(methods):
                            fig_comparison.add_trace(go.Bar(
                                name=method.replace(' (%)', ''),
                                x=comparison_df['Symbol'],
                                y=comparison_df[method],
                                marker_color=colors[i],
                                opacity=0.7
                            ))
                        
                        fig_comparison.update_layout(
                            title='Position Sizing Method Comparison',
                            xaxis_title='Symbol',
                            yaxis_title='Weight (%)',
                            barmode='group',
                            height=500
                        )
                        st.plotly_chart(fig_comparison, use_container_width=True)
                        
                        # Portfolio metrics comparison
                        st.subheader("Portfolio Metrics Comparison")
                        
                        current_vol = sizing_results['current_portfolio_vol']
                        target_vol_achieved = target_volatility  # Simplified
                        
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            st.metric(
                                "Current Portfolio Vol",
                                f"{current_vol*100:.2f}%"
                            )
                        
                        with col2:
                            st.metric(
                                "Target Portfolio Vol",
                                f"{target_volatility*100:.2f}%"
                            )
                        
                        with col3:
                            vol_difference = target_volatility - current_vol
                            st.metric(
                                "Volatility Adjustment",
                                f"{vol_difference*100:+.2f}%",
                                f"Scaling: {sizing_results['vol_target_scalar']:.2f}x"
                            )
                        
                        # Store sizing results
                        st.session_state.sizing_results = {
                            'comparison_df': comparison_df,
                            'sizing_results': sizing_results,
                            'kelly_sizes': kelly_sizes,
                            'var_based_sizes': var_based_sizes
                        }
        
        else:
            st.warning("Please calculate volatility metrics first in the Volatility Analysis tab.")
    
    with tab3:
        st.subheader("Risk-Based Position Sizing")
        
        if 'sizing_results' in st.session_state:
            st.write("**Position Size Recommendations:**")
            
            comparison_df = st.session_state.sizing_results['comparison_df']
            
            # Risk budget analysis
            st.write("**Risk Budget Allocation:**")
            
            risk_budget = st.slider("Total Risk Budget (%)", 10, 100, 100)
            
            # Calculate risk contribution for each method
            methods = ['Risk Parity (%)', 'Vol Target (%)', 'Kelly Criterion (%)']
            
            for method in methods:
                st.write(f"**{method.replace(' (%)', '')} Method:**")
                
                method_weights = comparison_df[method] / 100
                total_allocated = method_weights.sum()
                
                if total_allocated > 0:
                    scaled_weights = method_weights * (risk_budget / 100) / total_allocated
                    
                    risk_df = pd.DataFrame({
                        'Symbol': comparison_df['Symbol'],
                        'Recommended Weight (%)': scaled_weights * 100,
                        'Risk Contribution': scaled_weights * comparison_df['Symbol'].map(
                            lambda x: st.session_state.asset_metrics['volatilities'].get(x, 0)
                        ) * 100
                    })
                    
                    st.dataframe(risk_df, use_container_width=True)
            
            # Position size constraints
            st.write("**Position Size Constraints Analysis:**")
            
            constraints_df = comparison_df.copy()
            
            # Apply maximum position size constraint
            max_pos_size = st.slider("Maximum Position Size Constraint (%)", 5, 50, 20)
            
            for method in ['Risk Parity (%)', 'Vol Target (%)', 'Kelly Criterion (%)', 'VaR-Based (%)']:
                constraints_df[f'{method} (Constrained)'] = np.minimum(
                    constraints_df[method], 
                    max_pos_size
                )
            
            # Show constrained vs unconstrained
            constrained_cols = [col for col in constraints_df.columns if 'Constrained' in col]
            
            if constrained_cols:
                fig_constraints = go.Figure()
                
                for i, method in enumerate(['Risk Parity (%)', 'Vol Target (%)', 'Kelly Criterion (%)', 'VaR-Based (%)']):
                    constrained_method = f'{method} (Constrained)'
                    
                    # Original
                    fig_constraints.add_trace(go.Bar(
                        name=f'{method.replace(" (%)", "")} Original',
                        x=constraints_df['Symbol'],
                        y=constraints_df[method],
                        opacity=0.6,
                        marker_color=f'rgba({50 + i*50}, {100 + i*30}, {150 + i*20}, 0.6)'
                    ))
                    
                    # Constrained
                    fig_constraints.add_trace(go.Bar(
                        name=f'{method.replace(" (%)", "")} Constrained',
                        x=constraints_df['Symbol'],
                        y=constraints_df[constrained_method],
                        opacity=0.9,
                        marker_color=f'rgba({50 + i*50}, {100 + i*30}, {150 + i*20}, 0.9)'
                    ))
                
                fig_constraints.update_layout(
                    title='Position Size Constraints Impact',
                    xaxis_title='Symbol',
                    yaxis_title='Weight (%)',
                    barmode='group',
                    height=500
                )
                st.plotly_chart(fig_constraints, use_container_width=True)
        
        else:
            st.warning("Please calculate position sizes first in the Position Sizing Models tab.")
    
    with tab4:
        st.subheader("Portfolio Optimization Recommendations")
        
        if 'sizing_results' in st.session_state and 'asset_metrics' in st.session_state:
            comparison_df = st.session_state.sizing_results['comparison_df']
            asset_volatilities = st.session_state.asset_metrics['volatilities']
            asset_returns = st.session_state.asset_metrics['returns']
            
            st.write("**Optimization Summary:**")
            
            # Current portfolio metrics
            current_weights = comparison_df['Current Weight (%)'] / 100
            current_vol = np.sqrt(np.sum([(w * asset_volatilities.get(s, 0))**2 for w, s in 
                                        zip(current_weights, comparison_df['Symbol'])]))
            current_return = np.sum([w * asset_returns.get(s, 0) for w, s in 
                                   zip(current_weights, comparison_df['Symbol'])])
            
            # Recommended portfolio (Vol Target method)
            recommended_weights = comparison_df['Vol Target (%)'] / 100
            recommended_vol = np.sqrt(np.sum([(w * asset_volatilities.get(s, 0))**2 for w, s in 
                                            zip(recommended_weights, comparison_df['Symbol'])]))
            recommended_return = np.sum([w * asset_returns.get(s, 0) for w, s in 
                                       zip(recommended_weights, comparison_df['Symbol'])])
            
            # Display metrics
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Current Portfolio:**")
                st.metric("Expected Return", f"{current_return*100:.2f}%")
                st.metric("Volatility", f"{current_vol*100:.2f}%")
                current_sharpe = (current_return - 0.025) / current_vol if current_vol > 0 else 0
                st.metric("Sharpe Ratio", f"{current_sharpe:.3f}")
            
            with col2:
                st.write("**Optimized Portfolio:**")
                st.metric("Expected Return", f"{recommended_return*100:.2f}%")
                st.metric("Volatility", f"{recommended_vol*100:.2f}%")
                recommended_sharpe = (recommended_return - 0.025) / recommended_vol if recommended_vol > 0 else 0
                st.metric("Sharpe Ratio", f"{recommended_sharpe:.3f}")
            
            # Improvement metrics
            st.write("**Optimization Impact:**")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                return_improvement = recommended_return - current_return
                st.metric(
                    "Return Change",
                    f"{return_improvement*100:+.2f}%"
                )
            
            with col2:
                vol_improvement = recommended_vol - current_vol
                st.metric(
                    "Volatility Change",
                    f"{vol_improvement*100:+.2f}%"
                )
            
            with col3:
                sharpe_improvement = recommended_sharpe - current_sharpe
                st.metric(
                    "Sharpe Improvement",
                    f"{sharpe_improvement:+.3f}"
                )
            
            # Rebalancing recommendations
            st.subheader("Rebalancing Recommendations")
            
            rebalancing_df = pd.DataFrame({
                'Symbol': comparison_df['Symbol'],
                'Current (%)': comparison_df['Current Weight (%)'],
                'Target (%)': comparison_df['Vol Target (%)'],
                'Adjustment (%)': comparison_df['Vol Target (%)'] - comparison_df['Current Weight (%)'],
                'Action': ['Buy' if x > 0 else 'Sell' if x < 0 else 'Hold' 
                          for x in (comparison_df['Vol Target (%)'] - comparison_df['Current Weight (%)'])]
            })
            
            # Highlight significant adjustments
            threshold = 2.0  # 2% threshold for significant changes
            significant_changes = abs(rebalancing_df['Adjustment (%)']) > threshold
            
            if significant_changes.any():
                st.write("**Significant Rebalancing Required:**")
                st.dataframe(rebalancing_df[significant_changes], use_container_width=True)
            else:
                st.success("Portfolio is well-balanced. Minor adjustments only.")
                st.dataframe(rebalancing_df, use_container_width=True)
            
            # Implementation priority
            st.write("**Implementation Priority:**")
            
            # Sort by absolute adjustment size
            priority_df = rebalancing_df.copy()
            priority_df['Priority'] = abs(priority_df['Adjustment (%)'])
            priority_df = priority_df.sort_values('Priority', ascending=False)
            
            priority_df['Implementation Order'] = range(1, len(priority_df) + 1)
            
            st.dataframe(
                priority_df[['Symbol', 'Action', 'Adjustment (%)', 'Implementation Order']], 
                use_container_width=True
            )
            
            # Cost considerations
            st.write("**Transaction Cost Considerations:**")
            
            trading_cost_pct = st.number_input("Estimated Trading Cost (%)", 0.0, 2.0, 0.1, 0.01)
            
            total_turnover = abs(rebalancing_df['Adjustment (%)']).sum()
            estimated_cost = total_turnover * trading_cost_pct / 100
            
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Total Turnover", f"{total_turnover:.1f}%")
            with col2:
                st.metric("Estimated Trading Cost", f"{estimated_cost:.3f}%")
            
            # Final recommendations
            st.subheader("Key Recommendations")
            
            if recommended_sharpe > current_sharpe + 0.1:
                st.success("**Strong Optimization Opportunity**")
                st.write("- Significant improvement in risk-adjusted returns possible")
                st.write("- Recommend implementing suggested rebalancing")
            elif recommended_sharpe > current_sharpe:
                st.info("**Moderate Optimization Opportunity**")
                st.write("- Some improvement in risk-adjusted returns possible")
                st.write("- Consider gradual rebalancing")
            else:
                st.warning("**Limited Optimization Benefit**")
                st.write("- Current allocation is reasonably efficient")
                st.write("- Focus on monitoring and minor adjustments")
        
        else:
            st.warning("Please complete the previous analysis steps first.")
