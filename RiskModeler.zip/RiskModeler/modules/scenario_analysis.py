import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import yfinance as yf

def load_historical_scenario_data():
    """Load historical market data for major crisis periods"""
    scenarios = {
        "2008 Financial Crisis": {
            "start_date": "2007-10-01",
            "end_date": "2009-03-31",
            "description": "Global financial meltdown triggered by subprime mortgage crisis",
            "key_metrics": {
                "S&P 500 Peak-to-Trough": "-56.8%",
                "Duration": "17 months",
                "VIX Peak": "80.86"
            }
        },
        "COVID-19 Pandemic": {
            "start_date": "2020-02-01",
            "end_date": "2020-05-31",
            "description": "Market crash due to global pandemic and lockdowns",
            "key_metrics": {
                "S&P 500 Peak-to-Trough": "-33.9%",
                "Duration": "1 month",
                "VIX Peak": "82.69"
            }
        },
        "Dot-com Bubble": {
            "start_date": "2000-03-01",
            "end_date": "2002-10-31",
            "description": "Technology stock bubble burst",
            "key_metrics": {
                "NASDAQ Peak-to-Trough": "-78%",
                "Duration": "31 months",
                "Tech Stock Collapse": "Severe"
            }
        },
        "European Debt Crisis": {
            "start_date": "2010-04-01",
            "end_date": "2012-12-31",
            "description": "Sovereign debt crisis in European Union",
            "key_metrics": {
                "European Markets": "-30% to -50%",
                "Duration": "32 months",
                "Currency Impact": "EUR weakening"
            }
        }
    }
    return scenarios

def calculate_scenario_impact(portfolio_data, market_data, scenario_returns):
    """Calculate portfolio impact under historical scenario"""
    try:
        if portfolio_data is None or market_data is None:
            return None
        
        portfolio_impact = 0
        security_impacts = {}
        
        for _, holding in portfolio_data.iterrows():
            symbol = holding['Symbol']
            weight = holding.get('Weight', 0)
            
            if symbol in scenario_returns:
                security_return = scenario_returns[symbol]
                impact = weight * security_return
                portfolio_impact += impact
                security_impacts[symbol] = {
                    'return': security_return,
                    'weight': weight,
                    'contribution': impact
                }
        
        return portfolio_impact, security_impacts
    
    except Exception as e:
        st.error(f"Error calculating scenario impact: {e}")
        return None, None

def show_scenario_analysis():
    st.header("🌊 Historical Scenario Analysis")
    
    # Check if required data is available
    if st.session_state.portfolio_data is None:
        st.warning("Please load portfolio data first in the Data Input section.")
        return
    
    st.subheader("Major Historical Market Events")
    st.write("""
    Analyze how your portfolio would have performed during major historical market crises.
    This analysis helps understand potential vulnerabilities and stress points.
    """)
    
    # Load scenario definitions
    scenarios = load_historical_scenario_data()
    
    # Scenario selection
    selected_scenario = st.selectbox(
        "Select Historical Scenario:",
        list(scenarios.keys())
    )
    
    scenario_info = scenarios[selected_scenario]
    
    # Display scenario information
    st.subheader(f"Scenario: {selected_scenario}")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Period:**")
        st.write(f"{scenario_info['start_date']} to {scenario_info['end_date']}")
        st.write("**Description:**")
        st.write(scenario_info['description'])
    
    with col2:
        st.write("**Key Impact Metrics:**")
        for metric, value in scenario_info['key_metrics'].items():
            st.write(f"- **{metric}:** {value}")
    
    # Load historical data for scenario
    if st.button("Analyze Scenario Impact"):
        with st.spinner(f"Loading historical data for {selected_scenario}..."):
            try:
                start_date = scenario_info['start_date']
                end_date = scenario_info['end_date']
                
                # Get portfolio symbols
                portfolio_symbols = st.session_state.portfolio_data['Symbol'].tolist()
                
                # Add market indices
                all_symbols = portfolio_symbols + ['^GSPC', '^VIX', '^DJI']
                
                scenario_data = {}
                scenario_returns = {}
                
                # Load data for each symbol
                for symbol in all_symbols:
                    try:
                        ticker = yf.Ticker(symbol)
                        data = ticker.history(start=start_date, end=end_date)
                        
                        if not data.empty:
                            # Calculate total return during period
                            start_price = data['Close'].iloc[0]
                            end_price = data['Close'].iloc[-1]
                            total_return = (end_price - start_price) / start_price
                            
                            scenario_data[symbol] = data
                            scenario_returns[symbol] = total_return
                    
                    except Exception as e:
                        st.warning(f"Could not load data for {symbol}: {e}")
                        continue
                
                if scenario_returns:
                    # Calculate portfolio impact
                    portfolio_impact, security_impacts = calculate_scenario_impact(
                        st.session_state.portfolio_data, 
                        st.session_state.market_data, 
                        scenario_returns
                    )
                    
                    if portfolio_impact is not None:
                        # Display results
                        st.markdown("---")
                        st.subheader("Scenario Impact Results")
                        
                        # Portfolio impact summary
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            portfolio_value = 1000000  # Default portfolio value
                            if 'var_results' in st.session_state:
                                portfolio_value = st.session_state.var_results.get('portfolio_value', 1000000)
                            
                            impact_dollar = portfolio_impact * portfolio_value
                            st.metric(
                                "Total Portfolio Impact",
                                f"${impact_dollar:,.0f}",
                                f"{portfolio_impact*100:.2f}%"
                            )
                        
                        with col2:
                            market_return = scenario_returns.get('^GSPC', 0)
                            st.metric(
                                "S&P 500 Return",
                                f"{market_return*100:.2f}%"
                            )
                        
                        with col3:
                            excess_return = portfolio_impact - market_return
                            st.metric(
                                "Excess Return vs Market",
                                f"{excess_return*100:.2f}%"
                            )
                        
                        # Security-level impacts
                        if security_impacts:
                            st.subheader("Security-Level Impact Analysis")
                            
                            impact_df = pd.DataFrame({
                                'Symbol': list(security_impacts.keys()),
                                'Return (%)': [v['return']*100 for v in security_impacts.values()],
                                'Weight (%)': [v['weight']*100 for v in security_impacts.values()],
                                'Contribution (%)': [v['contribution']*100 for v in security_impacts.values()]
                            })
                            
                            st.dataframe(impact_df, use_container_width=True)
                            
                            # Contribution chart
                            fig_contrib = px.bar(
                                impact_df,
                                x='Symbol',
                                y='Contribution (%)',
                                title='Security Contribution to Portfolio Impact',
                                color='Contribution (%)',
                                color_continuous_scale='RdYlGn'
                            )
                            fig_contrib.update_layout(height=400)
                            st.plotly_chart(fig_contrib, use_container_width=True)
                            
                            # Return distribution
                            fig_returns = px.bar(
                                impact_df,
                                x='Symbol',
                                y='Return (%)',
                                title='Security Returns During Crisis',
                                color='Return (%)',
                                color_continuous_scale='RdYlGn'
                            )
                            fig_returns.update_layout(height=400)
                            st.plotly_chart(fig_returns, use_container_width=True)
                        
                        # Time series analysis
                        st.subheader("Crisis Timeline Analysis")
                        
                        if '^GSPC' in scenario_data and len(scenario_data['^GSPC']) > 0:
                            # Market performance timeline
                            market_data = scenario_data['^GSPC']
                            market_data['Cumulative_Return'] = (market_data['Close'] / market_data['Close'].iloc[0] - 1) * 100
                            
                            fig_timeline = go.Figure()
                            fig_timeline.add_trace(go.Scatter(
                                x=market_data.index,
                                y=market_data['Cumulative_Return'],
                                mode='lines',
                                name='S&P 500',
                                line=dict(color='blue')
                            ))
                            
                            # Add portfolio securities if available
                            for symbol in portfolio_symbols[:5]:  # Limit to top 5 for readability
                                if symbol in scenario_data:
                                    data = scenario_data[symbol]
                                    data['Cumulative_Return'] = (data['Close'] / data['Close'].iloc[0] - 1) * 100
                                    fig_timeline.add_trace(go.Scatter(
                                        x=data.index,
                                        y=data['Cumulative_Return'],
                                        mode='lines',
                                        name=symbol,
                                        opacity=0.7
                                    ))
                            
                            fig_timeline.update_layout(
                                title=f'Performance During {selected_scenario}',
                                xaxis_title='Date',
                                yaxis_title='Cumulative Return (%)',
                                height=500
                            )
                            st.plotly_chart(fig_timeline, use_container_width=True)
                        
                        # Risk metrics during crisis
                        st.subheader("Crisis Risk Metrics")
                        
                        if '^VIX' in scenario_data:
                            vix_data = scenario_data['^VIX']
                            max_vix = vix_data['Close'].max()
                            avg_vix = vix_data['Close'].mean()
                            
                            col1, col2 = st.columns(2)
                            with col1:
                                st.metric("Peak VIX Level", f"{max_vix:.2f}")
                            with col2:
                                st.metric("Average VIX Level", f"{avg_vix:.2f}")
                        
                        # Store scenario results
                        st.session_state.scenario_results = {
                            'scenario_name': selected_scenario,
                            'portfolio_impact': portfolio_impact,
                            'security_impacts': security_impacts,
                            'market_return': market_return,
                            'scenario_data': scenario_data
                        }
                        
                        # Risk implications
                        st.subheader("Risk Management Implications")
                        
                        if portfolio_impact < -0.2:  # More than 20% loss
                            st.error("**High Risk Exposure**")
                            st.write("- Portfolio shows significant vulnerability to this type of crisis")
                            st.write("- Consider diversification strategies")
                            st.write("- Implement hedging mechanisms")
                        elif portfolio_impact < -0.1:  # 10-20% loss
                            st.warning("**Moderate Risk Exposure**")
                            st.write("- Portfolio has moderate sensitivity to crisis events")
                            st.write("- Monitor correlation with market indices")
                            st.write("- Consider defensive positions")
                        else:
                            st.success("**Resilient Portfolio**")
                            st.write("- Portfolio shows good resilience to this crisis type")
                            st.write("- Maintain current risk management practices")
                
                else:
                    st.error("Unable to load historical data for the selected scenario.")
            
            except Exception as e:
                st.error(f"Error analyzing scenario: {e}")
    
    # Multi-scenario comparison
    st.markdown("---")
    st.subheader("Multi-Scenario Comparison")
    
    if st.button("Run All Scenarios"):
        with st.spinner("Running comprehensive scenario analysis..."):
            try:
                comparison_results = {}
                
                for scenario_name, scenario_info in scenarios.items():
                    try:
                        start_date = scenario_info['start_date']
                        end_date = scenario_info['end_date']
                        
                        # Quick calculation for comparison
                        ticker = yf.Ticker('^GSPC')
                        data = ticker.history(start=start_date, end=end_date)
                        
                        if not data.empty:
                            start_price = data['Close'].iloc[0]
                            end_price = data['Close'].iloc[-1]
                            market_return = (end_price - start_price) / start_price
                            
                            comparison_results[scenario_name] = {
                                'market_return': market_return,
                                'duration_months': len(data) / 22,  # Approximate months
                                'max_drawdown': ((data['Close'].min() - data['Close'].iloc[0]) / data['Close'].iloc[0])
                            }
                    
                    except Exception as e:
                        st.warning(f"Could not analyze {scenario_name}: {e}")
                        continue
                
                if comparison_results:
                    # Create comparison dataframe
                    comparison_df = pd.DataFrame(comparison_results).T
                    comparison_df['Market Return (%)'] = comparison_df['market_return'] * 100
                    comparison_df['Max Drawdown (%)'] = comparison_df['max_drawdown'] * 100
                    comparison_df['Duration (Months)'] = comparison_df['duration_months']
                    
                    # Display comparison table
                    display_df = comparison_df[['Market Return (%)', 'Max Drawdown (%)', 'Duration (Months)']]
                    st.dataframe(display_df, use_container_width=True)
                    
                    # Visualization
                    fig_comparison = go.Figure()
                    
                    fig_comparison.add_trace(go.Scatter(
                        x=comparison_df['Duration (Months)'],
                        y=comparison_df['Market Return (%)'],
                        mode='markers+text',
                        text=comparison_df.index,
                        textposition="top center",
                        marker=dict(
                            size=abs(comparison_df['Max Drawdown (%)']),
                            color=comparison_df['Market Return (%)'],
                            colorscale='RdYlGn',
                            colorbar=dict(title="Return (%)")
                        ),
                        name='Crisis Events'
                    ))
                    
                    fig_comparison.update_layout(
                        title='Crisis Comparison: Duration vs Return<br>(Bubble size = Max Drawdown)',
                        xaxis_title='Duration (Months)',
                        yaxis_title='Market Return (%)',
                        height=500
                    )
                    st.plotly_chart(fig_comparison, use_container_width=True)
            
            except Exception as e:
                st.error(f"Error in multi-scenario analysis: {e}")
