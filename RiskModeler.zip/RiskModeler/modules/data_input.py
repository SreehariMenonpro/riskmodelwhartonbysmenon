import streamlit as st
import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta
import numpy as np

def show_data_input():
    st.header("📊 Data Input & Portfolio Configuration")
    
    tab1, tab2, tab3 = st.tabs(["Portfolio Data", "Company Financials", "Market Data"])
    
    with tab1:
        st.subheader("Portfolio Holdings")
        
        # Manual portfolio input
        st.write("**Option 1: Manual Entry**")
        num_holdings = st.number_input("Number of holdings", min_value=1, max_value=50, value=5)
        
        portfolio_data = []
        for i in range(num_holdings):
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                symbol = st.text_input(f"Symbol {i+1}", key=f"symbol_{i}", value=f"AAPL" if i == 0 else "")
            with col2:
                shares = st.number_input(f"Shares {i+1}", min_value=0.0, key=f"shares_{i}", value=100.0)
            with col3:
                price = st.number_input(f"Price {i+1}", min_value=0.0, key=f"price_{i}", value=150.0)
            with col4:
                weight = st.number_input(f"Weight % {i+1}", min_value=0.0, max_value=100.0, key=f"weight_{i}", value=20.0)
            
            if symbol:
                portfolio_data.append({
                    'Symbol': symbol,
                    'Shares': shares,
                    'Price': price,
                    'Market_Value': shares * price,
                    'Weight': weight / 100
                })
        
        # File upload option
        st.write("**Option 2: Upload CSV File**")
        uploaded_file = st.file_uploader("Upload portfolio CSV", type=['csv'])
        
        if uploaded_file is not None:
            try:
                uploaded_portfolio = pd.read_csv(uploaded_file)
                st.write("Uploaded Portfolio:")
                st.dataframe(uploaded_portfolio)
                
                if st.button("Use Uploaded Portfolio"):
                    st.session_state.portfolio_data = uploaded_portfolio
                    st.success("Portfolio data loaded successfully!")
            except Exception as e:
                st.error(f"Error reading file: {e}")
        
        # Save manual portfolio
        if portfolio_data and st.button("Save Portfolio Data"):
            df_portfolio = pd.DataFrame(portfolio_data)
            st.session_state.portfolio_data = df_portfolio
            st.success("Portfolio data saved successfully!")
            st.dataframe(df_portfolio)
    
    with tab2:
        st.subheader("Company Financial Data")
        
        company_symbol = st.text_input("Enter company symbol for financial analysis", value="AAPL")
        
        if company_symbol:
            try:
                # Fetch financial data using yfinance
                ticker = yf.Ticker(company_symbol)
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write("**Balance Sheet Data (Most Recent)**")
                    balance_sheet = ticker.balance_sheet
                    if not balance_sheet.empty:
                        # Extract key financial metrics for Altman Z-Score
                        latest_bs = balance_sheet.iloc[:, 0]
                        
                        # Manual input with prefilled data
                        working_capital = st.number_input(
                            "Working Capital", 
                            value=float(latest_bs.get('Working Capital', 0)) if 'Working Capital' in latest_bs else 0.0
                        )
                        total_assets = st.number_input(
                            "Total Assets", 
                            value=float(latest_bs.get('Total Assets', 0)) if 'Total Assets' in latest_bs else 0.0
                        )
                        retained_earnings = st.number_input(
                            "Retained Earnings", 
                            value=float(latest_bs.get('Retained Earnings', 0)) if 'Retained Earnings' in latest_bs else 0.0
                        )
                        total_equity = st.number_input(
                            "Total Stockholder Equity", 
                            value=float(latest_bs.get('Stockholders Equity', 0)) if 'Stockholders Equity' in latest_bs else 0.0
                        )
                        total_liabilities = st.number_input(
                            "Total Liabilities", 
                            value=float(latest_bs.get('Total Liab', 0)) if 'Total Liab' in latest_bs else 0.0
                        )
                
                with col2:
                    st.write("**Income Statement Data (Most Recent)**")
                    income_stmt = ticker.financials
                    if not income_stmt.empty:
                        latest_is = income_stmt.iloc[:, 0]
                        
                        ebit = st.number_input(
                            "EBIT", 
                            value=float(latest_is.get('EBIT', 0)) if 'EBIT' in latest_is else 0.0
                        )
                        revenue = st.number_input(
                            "Total Revenue", 
                            value=float(latest_is.get('Total Revenue', 0)) if 'Total Revenue' in latest_is else 0.0
                        )
                
                # Market data
                st.write("**Market Data**")
                info = ticker.info
                market_cap = st.number_input(
                    "Market Capitalization", 
                    value=float(info.get('marketCap', 0)) if 'marketCap' in info else 0.0
                )
                
                # Save financial data
                if st.button("Save Financial Data"):
                    financial_data = {
                        'symbol': company_symbol,
                        'working_capital': working_capital,
                        'total_assets': total_assets,
                        'retained_earnings': retained_earnings,
                        'ebit': ebit,
                        'market_cap': market_cap,
                        'total_equity': total_equity,
                        'total_liabilities': total_liabilities,
                        'revenue': revenue
                    }
                    st.session_state.company_financials = financial_data
                    st.success("Financial data saved successfully!")
                    
            except Exception as e:
                st.error(f"Error fetching data for {company_symbol}: {e}")
    
    with tab3:
        st.subheader("Market Data Configuration")
        
        # Date range selection
        col1, col2 = st.columns(2)
        with col1:
            start_date = st.date_input(
                "Start Date", 
                value=datetime.now() - timedelta(days=365*2)
            )
        with col2:
            end_date = st.date_input(
                "End Date", 
                value=datetime.now()
            )
        
        # Benchmark indices
        st.write("**Benchmark Indices**")
        indices = st.multiselect(
            "Select benchmark indices",
            ["^GSPC", "^DJI", "^IXIC", "^RUT", "^VIX"],
            default=["^GSPC", "^VIX"]
        )
        
        # Risk-free rate
        risk_free_rate = st.number_input("Risk-free rate (%)", value=2.5, min_value=0.0, max_value=10.0) / 100
        
        if st.button("Load Market Data"):
            try:
                market_data = {}
                
                # Load benchmark data
                for index in indices:
                    ticker = yf.Ticker(index)
                    data = ticker.history(start=start_date, end=end_date)
                    market_data[index] = data
                
                # Load portfolio securities data if available
                if st.session_state.portfolio_data is not None:
                    for symbol in st.session_state.portfolio_data['Symbol'].unique():
                        ticker = yf.Ticker(symbol)
                        data = ticker.history(start=start_date, end=end_date)
                        market_data[symbol] = data
                
                market_data['risk_free_rate'] = risk_free_rate
                market_data['start_date'] = start_date
                market_data['end_date'] = end_date
                
                st.session_state.market_data = market_data
                st.success("Market data loaded successfully!")
                
                # Display summary
                st.write("**Data Summary:**")
                for symbol, data in market_data.items():
                    if isinstance(data, pd.DataFrame):
                        st.write(f"- {symbol}: {len(data)} observations")
                        
            except Exception as e:
                st.error(f"Error loading market data: {e}")
    
    # Display current data status
    st.sidebar.markdown("---")
    st.sidebar.subheader("Data Status")
    
    if st.session_state.portfolio_data is not None:
        st.sidebar.success("✅ Portfolio Data Loaded")
    else:
        st.sidebar.warning("⚠️ Portfolio Data Missing")
    
    if st.session_state.company_financials is not None:
        st.sidebar.success("✅ Financial Data Loaded")
    else:
        st.sidebar.warning("⚠️ Financial Data Missing")
    
    if st.session_state.market_data is not None:
        st.sidebar.success("✅ Market Data Loaded")
    else:
        st.sidebar.warning("⚠️ Market Data Missing")
