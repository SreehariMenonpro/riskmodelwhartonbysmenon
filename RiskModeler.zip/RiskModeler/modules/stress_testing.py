import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from scipy import stats
from utils.risk_calculations import calculate_portfolio_returns

def generate_stress_scenarios():
    """Generate various stress test scenarios"""
    scenarios = {
        "Interest Rate Shock": {
            "description": "Sudden 200 basis point increase in interest rates",
            "equity_impact": -0.15,
            "bond_impact": -0.08,
            "reit_impact": -0.20,
            "commodity_impact": -0.05,
            "volatility_multiplier": 2.0
        },
        "Equity Market Crash": {
            "description": "30% market decline similar to Black Monday",
            "equity_impact": -0.30,
            "bond_impact": 0.05,
            "reit_impact": -0.25,
            "commodity_impact": -0.15,
            "volatility_multiplier": 3.0
        },
        "Credit Crisis": {
            "description": "Corporate credit spread widening and liquidity crunch",
            "equity_impact": -0.25,
            "bond_impact": -0.12,
            "reit_impact": -0.30,
            "commodity_impact": -0.10,
            "volatility_multiplier": 2.5
        },
        "Currency Crisis": {
            "description": "Major currency devaluation and FX volatility",
            "equity_impact": -0.20,
            "bond_impact": -0.05,
            "reit_impact": -0.15,
            "commodity_impact": 0.10,
            "volatility_multiplier": 2.2
        },
        "Inflation Shock": {
            "description": "Unexpected surge in inflation to 8%+",
            "equity_impact": -0.18,
            "bond_impact": -0.15,
            "reit_impact": -0.10,
            "commodity_impact": 0.20,
            "volatility_multiplier": 1.8
        },
        "Geopolitical Crisis": {
            "description": "Major geopolitical event causing market disruption",
            "equity_impact": -0.22,
            "bond_impact": 0.03,
            "reit_impact": -0.18,
            "commodity_impact": 0.15,
            "volatility_multiplier": 2.8
        }
    }
    return scenarios

def classify_asset_type(symbol):
    """Classify asset type based on symbol (simplified)"""
    # This is a simplified classification - in practice, you'd use a more sophisticated method
    bond_indicators = ['AGG', 'BND', 'TLT', 'IEF', 'SHY', 'LQD', 'HYG']
    reit_indicators = ['VNQ', 'REIT', 'REZ', 'XLRE']
    commodity_indicators = ['GLD', 'SLV', 'OIL', 'DBA', 'DBC', 'USO']
    
    symbol_upper = symbol.upper()
    
    if any(indicator in symbol_upper for indicator in bond_indicators):
        return 'bond'
    elif any(indicator in symbol_upper for indicator in reit_indicators):
        return 'reit'
    elif any(indicator in symbol_upper for indicator in commodity_indicators):
        return 'commodity'
    else:
        return 'equity'

def apply_stress_scenario(portfolio_data, scenario):
    """Apply stress scenario to portfolio"""
    stressed_portfolio = portfolio_data.copy()
    stressed_returns = {}
    
    for _, holding in portfolio_data.iterrows():
        symbol = holding['Symbol']
        weight = holding.get('Weight', 0)
        asset_type = classify_asset_type(symbol)
        
        # Apply scenario impact based on asset type
        if asset_type == 'equity':
            impact = scenario['equity_impact']
        elif asset_type == 'bond':
            impact = scenario['bond_impact']
        elif asset_type == 'reit':
            impact = scenario['reit_impact']
        elif asset_type == 'commodity':
            impact = scenario['commodity_impact']
        else:
            impact = scenario['equity_impact']  # Default to equity
        
        stressed_returns[symbol] = {
            'impact': impact,
            'weight': weight,
            'contribution': weight * impact,
            'asset_type': asset_type
        }
    
    total_impact = sum([item['contribution'] for item in stressed_returns.values()])
    
    return total_impact, stressed_returns

def calculate_tail_risk_metrics(returns):
    """Calculate tail risk metrics"""
    if returns is None or len(returns) == 0:
        return {}
    
    returns_sorted = np.sort(returns)
    
    # Value at Risk at different confidence levels
    var_95 = np.percentile(returns_sorted, 5)
    var_99 = np.percentile(returns_sorted, 1)
    var_999 = np.percentile(returns_sorted, 0.1)
    
    # Expected Shortfall (Conditional VaR)
    es_95 = np.mean(returns_sorted[returns_sorted <= var_95])
    es_99 = np.mean(returns_sorted[returns_sorted <= var_99])
    
    # Maximum drawdown calculation
    cumulative_returns = np.cumprod(1 + returns)
    running_max = np.maximum.accumulate(cumulative_returns)
    drawdowns = (cumulative_returns - running_max) / running_max
    max_drawdown = np.min(drawdowns)
    
    # Tail ratio
    tail_ratio = abs(np.percentile(returns_sorted, 95)) / abs(np.percentile(returns_sorted, 5))
    
    return {
        'var_95': var_95,
        'var_99': var_99,
        'var_999': var_999,
        'es_95': es_95,
        'es_99': es_99,
        'max_drawdown': max_drawdown,
        'tail_ratio': tail_ratio
    }

def show_stress_testing():
    st.header("⚡ Stress Testing & Tail Risk Analysis")
    
    # Check if required data is available
    if st.session_state.portfolio_data is None:
        st.warning("Please load portfolio data first in the Data Input section.")
        return
    
    st.subheader("Extreme Market Scenarios")
    st.write("""
    Stress testing evaluates portfolio performance under extreme but plausible market conditions.
    This analysis helps identify vulnerabilities and potential losses during tail events.
    """)
    
    # Load stress scenarios
    scenarios = generate_stress_scenarios()
    
    tab1, tab2, tab3 = st.tabs(["Scenario Stress Tests", "Tail Risk Analysis", "Custom Stress Tests"])
    
    with tab1:
        st.subheader("Predefined Stress Scenarios")
        
        # Portfolio composition analysis
        st.write("**Portfolio Asset Classification:**")
        
        asset_composition = {}
        total_weight = 0
        
        for _, holding in st.session_state.portfolio_data.iterrows():
            symbol = holding['Symbol']
            weight = holding.get('Weight', 0)
            asset_type = classify_asset_type(symbol)
            
            if asset_type not in asset_composition:
                asset_composition[asset_type] = 0
            asset_composition[asset_type] += weight
            total_weight += weight
        
        # Normalize weights
        if total_weight > 0:
            for asset_type in asset_composition:
                asset_composition[asset_type] = asset_composition[asset_type] / total_weight
        
        # Display asset composition
        composition_df = pd.DataFrame({
            'Asset Type': list(asset_composition.keys()),
            'Weight (%)': [v*100 for v in asset_composition.values()]
        })
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.dataframe(composition_df, use_container_width=True)
        
        with col2:
            fig_pie = px.pie(
                composition_df,
                values='Weight (%)',
                names='Asset Type',
                title='Portfolio Asset Allocation'
            )
            st.plotly_chart(fig_pie, use_container_width=True)
        
        # Run stress scenarios
        st.write("**Stress Test Results:**")
        
        if st.button("Run All Stress Scenarios"):
            stress_results = {}
            portfolio_value = 1000000  # Default
            
            if 'var_results' in st.session_state:
                portfolio_value = st.session_state.var_results.get('portfolio_value', 1000000)
            
            for scenario_name, scenario in scenarios.items():
                total_impact, security_impacts = apply_stress_scenario(
                    st.session_state.portfolio_data, 
                    scenario
                )
                
                stress_results[scenario_name] = {
                    'total_impact': total_impact,
                    'dollar_impact': total_impact * portfolio_value,
                    'security_impacts': security_impacts,
                    'description': scenario['description']
                }
            
            # Display results summary
            results_df = pd.DataFrame({
                'Scenario': list(stress_results.keys()),
                'Portfolio Impact (%)': [v['total_impact']*100 for v in stress_results.values()],
                'Dollar Impact ($)': [v['dollar_impact'] for v in stress_results.values()],
                'Description': [v['description'] for v in stress_results.values()]
            })
            
            st.dataframe(results_df, use_container_width=True)
            
            # Stress test visualization
            fig_stress = px.bar(
                results_df,
                x='Scenario',
                y='Portfolio Impact (%)',
                title='Stress Test Results - Portfolio Impact',
                color='Portfolio Impact (%)',
                color_continuous_scale='RdYlGn_r'
            )
            fig_stress.update_layout(height=400, xaxis_tickangle=-45)
            st.plotly_chart(fig_stress, use_container_width=True)
            
            # Detailed analysis for worst scenario
            worst_scenario = min(stress_results.keys(), key=lambda k: stress_results[k]['total_impact'])
            
            st.subheader(f"Detailed Analysis: {worst_scenario}")
            st.write(f"**Description:** {stress_results[worst_scenario]['description']}")
            
            worst_security_impacts = stress_results[worst_scenario]['security_impacts']
            
            security_detail_df = pd.DataFrame({
                'Symbol': list(worst_security_impacts.keys()),
                'Asset Type': [v['asset_type'] for v in worst_security_impacts.values()],
                'Weight (%)': [v['weight']*100 for v in worst_security_impacts.values()],
                'Impact (%)': [v['impact']*100 for v in worst_security_impacts.values()],
                'Contribution (%)': [v['contribution']*100 for v in worst_security_impacts.values()]
            })
            
            st.dataframe(security_detail_df, use_container_width=True)
            
            # Store stress test results
            st.session_state.stress_results = stress_results
    
    with tab2:
        st.subheader("Tail Risk Analysis")
        
        if st.session_state.market_data is not None:
            # Calculate portfolio returns for tail risk analysis
            portfolio_returns = calculate_portfolio_returns(
                st.session_state.portfolio_data, 
                st.session_state.market_data
            )
            
            if portfolio_returns is not None and len(portfolio_returns) > 0:
                # Calculate tail risk metrics
                tail_metrics = calculate_tail_risk_metrics(portfolio_returns)
                
                if tail_metrics:
                    st.write("**Tail Risk Metrics:**")
                    
                    # Display VaR metrics
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.metric("VaR 95%", f"{tail_metrics['var_95']*100:.2f}%")
                        st.metric("VaR 99%", f"{tail_metrics['var_99']*100:.2f}%")
                    
                    with col2:
                        st.metric("VaR 99.9%", f"{tail_metrics['var_999']*100:.2f}%")
                        st.metric("Expected Shortfall 95%", f"{tail_metrics['es_95']*100:.2f}%")
                    
                    with col3:
                        st.metric("Expected Shortfall 99%", f"{tail_metrics['es_99']*100:.2f}%")
                        st.metric("Maximum Drawdown", f"{tail_metrics['max_drawdown']*100:.2f}%")
                    
                    # Tail distribution analysis
                    fig_tail = go.Figure()
                    
                    # Histogram of returns
                    fig_tail.add_trace(go.Histogram(
                        x=portfolio_returns*100,
                        nbinsx=50,
                        name='Return Distribution',
                        opacity=0.7
                    ))
                    
                    # Add VaR lines
                    fig_tail.add_vline(
                        x=tail_metrics['var_95']*100,
                        line_dash="dash",
                        line_color="orange",
                        annotation_text="VaR 95%"
                    )
                    fig_tail.add_vline(
                        x=tail_metrics['var_99']*100,
                        line_dash="dash",
                        line_color="red",
                        annotation_text="VaR 99%"
                    )
                    
                    fig_tail.update_layout(
                        title='Portfolio Return Distribution with Tail Risk Metrics',
                        xaxis_title='Daily Return (%)',
                        yaxis_title='Frequency',
                        height=400
                    )
                    st.plotly_chart(fig_tail, use_container_width=True)
                    
                    # Q-Q plot for normality assessment
                    st.subheader("Normality Assessment")
                    
                    # Calculate theoretical quantiles
                    sorted_returns = np.sort(portfolio_returns)
                    n = len(sorted_returns)
                    theoretical_quantiles = stats.norm.ppf(np.arange(1, n+1) / (n+1))
                    
                    fig_qq = go.Figure()
                    fig_qq.add_trace(go.Scatter(
                        x=theoretical_quantiles,
                        y=sorted_returns,
                        mode='markers',
                        name='Data Points'
                    ))
                    
                    # Add reference line
                    min_val = min(theoretical_quantiles.min(), sorted_returns.min())
                    max_val = max(theoretical_quantiles.max(), sorted_returns.max())
                    fig_qq.add_trace(go.Scatter(
                        x=[min_val, max_val],
                        y=[min_val, max_val],
                        mode='lines',
                        name='Normal Line',
                        line=dict(color='red', dash='dash')
                    ))
                    
                    fig_qq.update_layout(
                        title='Q-Q Plot: Actual vs Normal Distribution',
                        xaxis_title='Theoretical Quantiles',
                        yaxis_title='Sample Quantiles',
                        height=400
                    )
                    st.plotly_chart(fig_qq, use_container_width=True)
                    
                    # Extreme value analysis
                    st.subheader("Extreme Value Analysis")
                    
                    # Block maxima method
                    block_size = 22  # Monthly blocks (22 trading days)
                    num_blocks = len(portfolio_returns) // block_size
                    
                    if num_blocks > 10:  # Ensure sufficient data
                        block_minima = []
                        for i in range(num_blocks):
                            start_idx = i * block_size
                            end_idx = start_idx + block_size
                            block_data = portfolio_returns[start_idx:end_idx]
                            block_minima.append(np.min(block_data))
                        
                        block_minima = np.array(block_minima)
                        
                        # Fit GEV distribution to block minima
                        try:
                            # For minima, we negate the data to fit maxima distribution
                            gev_params = stats.genextreme.fit(-block_minima)
                            
                            # Calculate extreme quantiles
                            extreme_1y = -stats.genextreme.ppf(0.01, *gev_params)  # 1% annual probability
                            extreme_5y = -stats.genextreme.ppf(0.002, *gev_params)  # 0.2% (1/5 year)
                            
                            col1, col2 = st.columns(2)
                            with col1:
                                st.metric("1-Year Extreme Loss", f"{extreme_1y*100:.2f}%")
                            with col2:
                                st.metric("5-Year Extreme Loss", f"{extreme_5y*100:.2f}%")
                            
                        except Exception as e:
                            st.warning(f"Could not fit extreme value distribution: {e}")
            
            else:
                st.warning("Unable to calculate portfolio returns for tail risk analysis.")
        
        else:
            st.warning("Market data required for tail risk analysis.")
    
    with tab3:
        st.subheader("Custom Stress Test Builder")
        
        st.write("Design your own stress scenario:")
        
        # Custom scenario inputs
        scenario_name = st.text_input("Scenario Name", value="Custom Stress Test")
        scenario_description = st.text_area("Scenario Description", 
                                          value="Custom market stress scenario")
        
        col1, col2 = st.columns(2)
        
        with col1:
            equity_shock = st.slider("Equity Impact (%)", -50, 20, -20) / 100
            bond_shock = st.slider("Bond Impact (%)", -30, 15, -5) / 100
        
        with col2:
            reit_shock = st.slider("REIT Impact (%)", -40, 10, -15) / 100
            commodity_shock = st.slider("Commodity Impact (%)", -30, 30, 5) / 100
        
        volatility_multiplier = st.slider("Volatility Multiplier", 1.0, 5.0, 2.0, 0.1)
        
        if st.button("Run Custom Stress Test"):
            custom_scenario = {
                'description': scenario_description,
                'equity_impact': equity_shock,
                'bond_impact': bond_shock,
                'reit_impact': reit_shock,
                'commodity_impact': commodity_shock,
                'volatility_multiplier': volatility_multiplier
            }
            
            total_impact, security_impacts = apply_stress_scenario(
                st.session_state.portfolio_data, 
                custom_scenario
            )
            
            portfolio_value = 1000000
            if 'var_results' in st.session_state:
                portfolio_value = st.session_state.var_results.get('portfolio_value', 1000000)
            
            dollar_impact = total_impact * portfolio_value
            
            # Display results
            st.markdown("---")
            st.subheader("Custom Stress Test Results")
            
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Portfolio Impact", f"{total_impact*100:.2f}%")
            with col2:
                st.metric("Dollar Impact", f"${dollar_impact:,.0f}")
            
            # Security-level results
            if security_impacts:
                custom_df = pd.DataFrame({
                    'Symbol': list(security_impacts.keys()),
                    'Asset Type': [v['asset_type'] for v in security_impacts.values()],
                    'Impact (%)': [v['impact']*100 for v in security_impacts.values()],
                    'Weight (%)': [v['weight']*100 for v in security_impacts.values()],
                    'Contribution (%)': [v['contribution']*100 for v in security_impacts.values()]
                })
                
                st.dataframe(custom_df, use_container_width=True)
                
                # Visualization
                fig_custom = px.bar(
                    custom_df,
                    x='Symbol',
                    y='Contribution (%)',
                    title='Custom Stress Test - Security Contributions',
                    color='Asset Type'
                )
                fig_custom.update_layout(height=400)
                st.plotly_chart(fig_custom, use_container_width=True)
    
    # Risk management recommendations
    st.markdown("---")
    st.subheader("Risk Management Recommendations")
    
    if 'stress_results' in st.session_state:
        stress_results = st.session_state.stress_results
        worst_case_impact = min([v['total_impact'] for v in stress_results.values()])
        
        if worst_case_impact < -0.3:  # More than 30% loss
            st.error("**High Stress Risk Exposure**")
            st.write("- Portfolio shows extreme vulnerability to stress scenarios")
            st.write("- Consider significant portfolio restructuring")
            st.write("- Implement comprehensive hedging strategies")
            st.write("- Reduce concentration risk")
        elif worst_case_impact < -0.2:  # 20-30% loss
            st.warning("**Moderate Stress Risk**")
            st.write("- Portfolio has notable stress scenario sensitivity")
            st.write("- Consider tactical hedging strategies")
            st.write("- Monitor correlation exposures")
            st.write("- Implement stop-loss mechanisms")
        else:
            st.success("**Acceptable Stress Risk Level**")
            st.write("- Portfolio shows reasonable resilience to stress scenarios")
            st.write("- Maintain current risk management framework")
            st.write("- Continue monitoring tail risks")
