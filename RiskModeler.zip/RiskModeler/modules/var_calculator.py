import streamlit as st
import pandas as pd
import numpy as np
from scipy import stats
import plotly.graph_objects as go
import plotly.express as px
from utils.risk_calculations import calculate_portfolio_returns, monte_carlo_simulation

def show_var_calculator():
    st.header("📈 Value at Risk (VaR) Calculator")
    
    # Check if required data is available
    if st.session_state.portfolio_data is None or st.session_state.market_data is None:
        st.warning("Please load portfolio and market data first in the Data Input section.")
        return
    
    # VaR Configuration
    st.subheader("VaR Configuration")
    
    col1, col2, col3 = st.columns(3)
    with col1:
        confidence_level = st.selectbox("Confidence Level", [90, 95, 99], index=1) / 100
    with col2:
        time_horizon = st.selectbox("Time Horizon (days)", [1, 5, 10, 22], index=0)
    with col3:
        portfolio_value = st.number_input("Portfolio Value ($)", value=1000000.0, min_value=1000.0)
    
    # Method selection
    st.subheader("VaR Calculation Methods")
    
    tab1, tab2, tab3 = st.tabs(["Parametric VaR", "Historical VaR", "Monte Carlo VaR"])
    
    try:
        # Calculate portfolio returns
        portfolio_returns = calculate_portfolio_returns(
            st.session_state.portfolio_data, 
            st.session_state.market_data
        )
        
        if portfolio_returns is None or len(portfolio_returns) == 0:
            st.error("Unable to calculate portfolio returns. Please check your data.")
            return
        
        with tab1:
            st.subheader("Parametric VaR (Normal Distribution)")
            
            # Calculate parametric VaR
            mean_return = np.mean(portfolio_returns)
            std_return = np.std(portfolio_returns)
            
            # Adjust for time horizon
            adjusted_mean = mean_return * time_horizon
            adjusted_std = std_return * np.sqrt(time_horizon)
            
            # Calculate VaR
            z_score = stats.norm.ppf(1 - confidence_level)
            var_parametric = portfolio_value * (adjusted_mean - z_score * adjusted_std)
            var_parametric_pct = (adjusted_mean - z_score * adjusted_std) * 100
            
            # Display results
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Daily Mean Return", f"{mean_return*100:.3f}%")
            with col2:
                st.metric("Daily Volatility", f"{std_return*100:.3f}%")
            with col3:
                st.metric("Sharpe Ratio", f"{mean_return/std_return:.3f}" if std_return > 0 else "N/A")
            
            st.markdown("---")
            col1, col2 = st.columns(2)
            with col1:
                st.metric(
                    f"Parametric VaR ({confidence_level*100:.0f}%)", 
                    f"${var_parametric:,.0f}",
                    f"{var_parametric_pct:.2f}%"
                )
            with col2:
                expected_shortfall = portfolio_value * (adjusted_mean - adjusted_std * stats.norm.pdf(z_score) / (1 - confidence_level))
                st.metric(
                    "Expected Shortfall (CVaR)", 
                    f"${expected_shortfall:,.0f}",
                    f"{(expected_shortfall/portfolio_value)*100:.2f}%"
                )
            
            # Plot distribution
            fig = go.Figure()
            
            x = np.linspace(adjusted_mean - 4*adjusted_std, adjusted_mean + 4*adjusted_std, 1000)
            y = stats.norm.pdf(x, adjusted_mean, adjusted_std)
            
            fig.add_trace(go.Scatter(x=x*100, y=y, mode='lines', name='Normal Distribution'))
            
            # Add VaR line
            var_line = adjusted_mean - z_score * adjusted_std
            fig.add_vline(x=var_line*100, line_dash="dash", line_color="red", 
                         annotation_text=f"VaR {confidence_level*100:.0f}%")
            
            fig.update_layout(
                title="Parametric VaR - Normal Distribution",
                xaxis_title="Return (%)",
                yaxis_title="Density",
                height=400
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with tab2:
            st.subheader("Historical VaR (Empirical Distribution)")
            
            # Calculate historical VaR
            if time_horizon > 1:
                # Calculate overlapping returns for time horizon
                rolling_returns = []
                for i in range(len(portfolio_returns) - time_horizon + 1):
                    period_return = np.sum(portfolio_returns[i:i+time_horizon])
                    rolling_returns.append(period_return)
                historical_returns = np.array(rolling_returns)
            else:
                historical_returns = portfolio_returns
            
            # Sort returns and find VaR
            sorted_returns = np.sort(historical_returns)
            var_index = int((1 - confidence_level) * len(sorted_returns))
            var_historical = portfolio_value * sorted_returns[var_index]
            var_historical_pct = sorted_returns[var_index] * 100
            
            # Expected shortfall
            es_historical = portfolio_value * np.mean(sorted_returns[:var_index])
            
            # Display results
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Historical Observations", f"{len(historical_returns):,}")
            with col2:
                st.metric(
                    f"Historical VaR ({confidence_level*100:.0f}%)", 
                    f"${var_historical:,.0f}",
                    f"{var_historical_pct:.2f}%"
                )
            with col3:
                st.metric(
                    "Historical ES", 
                    f"${es_historical:,.0f}",
                    f"{(es_historical/portfolio_value)*100:.2f}%"
                )
            
            # Plot histogram
            fig = go.Figure()
            fig.add_trace(go.Histogram(x=historical_returns*100, nbinsx=50, name='Historical Returns'))
            fig.add_vline(x=sorted_returns[var_index]*100, line_dash="dash", line_color="red", 
                         annotation_text=f"VaR {confidence_level*100:.0f}%")
            
            fig.update_layout(
                title="Historical VaR - Empirical Distribution",
                xaxis_title="Return (%)",
                yaxis_title="Frequency",
                height=400
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with tab3:
            st.subheader("Monte Carlo VaR")
            
            # Monte Carlo parameters
            col1, col2 = st.columns(2)
            with col1:
                num_simulations = st.selectbox("Number of Simulations", [1000, 5000, 10000], index=1)
            with col2:
                distribution_type = st.selectbox("Distribution", ["Normal", "t-Distribution"], index=0)
            
            if st.button("Run Monte Carlo Simulation"):
                with st.spinner("Running Monte Carlo simulation..."):
                    # Run simulation
                    mc_returns = monte_carlo_simulation(
                        portfolio_returns, 
                        num_simulations, 
                        time_horizon,
                        distribution_type
                    )
                    
                    # Calculate VaR
                    sorted_mc_returns = np.sort(mc_returns)
                    var_index = int((1 - confidence_level) * len(sorted_mc_returns))
                    var_mc = portfolio_value * sorted_mc_returns[var_index]
                    var_mc_pct = sorted_mc_returns[var_index] * 100
                    
                    # Expected shortfall
                    es_mc = portfolio_value * np.mean(sorted_mc_returns[:var_index])
                    
                    # Display results
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Simulations", f"{num_simulations:,}")
                    with col2:
                        st.metric(
                            f"Monte Carlo VaR ({confidence_level*100:.0f}%)", 
                            f"${var_mc:,.0f}",
                            f"{var_mc_pct:.2f}%"
                        )
                    with col3:
                        st.metric(
                            "Monte Carlo ES", 
                            f"${es_mc:,.0f}",
                            f"{(es_mc/portfolio_value)*100:.2f}%"
                        )
                    
                    # Plot simulation results
                    fig = go.Figure()
                    fig.add_trace(go.Histogram(x=mc_returns*100, nbinsx=50, name='Simulated Returns'))
                    fig.add_vline(x=sorted_mc_returns[var_index]*100, line_dash="dash", line_color="red", 
                                 annotation_text=f"VaR {confidence_level*100:.0f}%")
                    
                    fig.update_layout(
                        title=f"Monte Carlo VaR - {distribution_type}",
                        xaxis_title="Return (%)",
                        yaxis_title="Frequency",
                        height=400
                    )
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Store results in session state
                    st.session_state.var_results = {
                        'parametric_var': var_parametric,
                        'historical_var': var_historical,
                        'monte_carlo_var': var_mc,
                        'confidence_level': confidence_level,
                        'time_horizon': time_horizon,
                        'portfolio_value': portfolio_value
                    }
        
        # Comparison table
        st.subheader("VaR Method Comparison")
        
        if 'var_results' in st.session_state:
            comparison_data = {
                'Method': ['Parametric', 'Historical', 'Monte Carlo'],
                'VaR ($)': [
                    f"${var_parametric:,.0f}",
                    f"${var_historical:,.0f}",
                    f"${st.session_state.var_results['monte_carlo_var']:,.0f}"
                ],
                'VaR (%)': [
                    f"{var_parametric_pct:.2f}%",
                    f"{var_historical_pct:.2f}%",
                    f"{(st.session_state.var_results['monte_carlo_var']/portfolio_value)*100:.2f}%"
                ]
            }
            st.table(pd.DataFrame(comparison_data))
        
    except Exception as e:
        st.error(f"Error calculating VaR: {e}")
        st.write("Please ensure your portfolio and market data are properly formatted.")
