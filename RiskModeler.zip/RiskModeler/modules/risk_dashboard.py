import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta

def create_risk_gauge(value, title, min_val=0, max_val=100, thresholds=[30, 70]):
    """Create a risk gauge chart"""
    fig = go.Figure(go.Indicator(
        mode = "gauge+number",
        value = value,
        domain = {'x': [0, 1], 'y': [0, 1]},
        title = {'text': title},
        gauge = {
            'axis': {'range': [min_val, max_val]},
            'bar': {'color': "darkblue"},
            'steps': [
                {'range': [min_val, thresholds[0]], 'color': "lightgreen"},
                {'range': [thresholds[0], thresholds[1]], 'color': "yellow"},
                {'range': [thresholds[1], max_val], 'color': "lightcoral"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': value
            }
        }
    ))
    fig.update_layout(height=300)
    return fig

def calculate_risk_score(portfolio_data, market_data, var_results=None, zscore_results=None, 
                        stress_results=None, scenario_results=None):
    """Calculate an overall risk score based on various metrics"""
    risk_components = {}
    total_score = 0
    max_score = 0
    
    # VaR component (25% weight)
    if var_results:
        var_pct = abs(var_results.get('parametric_var', 0)) / var_results.get('portfolio_value', 1000000)
        if var_pct < 0.05:  # Less than 5% VaR
            var_score = 20
        elif var_pct < 0.1:  # 5-10% VaR
            var_score = 50
        else:  # More than 10% VaR
            var_score = 80
        
        risk_components['VaR Risk'] = var_score
        total_score += var_score * 0.25
    max_score += 25
    
    # Z-Score component (20% weight)
    if zscore_results:
        z_score = zscore_results.get('z_score', 2.0)
        if z_score >= 2.99:
            zscore_risk = 20
        elif z_score >= 1.8:
            zscore_risk = 50
        else:
            zscore_risk = 80
        
        risk_components['Credit Risk'] = zscore_risk
        total_score += zscore_risk * 0.20
    max_score += 20
    
    # Stress test component (25% weight)
    if stress_results:
        worst_stress = min([v['total_impact'] for v in stress_results.values()])
        if worst_stress > -0.15:  # Less than 15% loss
            stress_risk = 30
        elif worst_stress > -0.30:  # 15-30% loss
            stress_risk = 60
        else:  # More than 30% loss
            stress_risk = 90
        
        risk_components['Stress Risk'] = stress_risk
        total_score += stress_risk * 0.25
    max_score += 25
    
    # Concentration risk (15% weight)
    if portfolio_data is not None:
        weights = portfolio_data.get('Weight', [])
        if len(weights) > 0:
            max_weight = max(weights) if hasattr(weights, '__iter__') else weights
            if max_weight < 0.2:  # No position > 20%
                concentration_risk = 20
            elif max_weight < 0.4:  # Largest position 20-40%
                concentration_risk = 50
            else:  # Largest position > 40%
                concentration_risk = 80
        else:
            concentration_risk = 50
        
        risk_components['Concentration Risk'] = concentration_risk
        total_score += concentration_risk * 0.15
    max_score += 15
    
    # Market volatility (15% weight)
    if market_data and '^VIX' in market_data:
        try:
            current_vix = market_data['^VIX']['Close'].iloc[-1]
            if current_vix < 20:
                market_risk = 25
            elif current_vix < 30:
                market_risk = 50
            else:
                market_risk = 75
        except:
            market_risk = 50
        
        risk_components['Market Volatility'] = market_risk
        total_score += market_risk * 0.15
    max_score += 15
    
    # Normalize to 0-100 scale
    overall_score = (total_score / max_score * 100) if max_score > 0 else 50
    
    return overall_score, risk_components

def show_dashboard():
    st.header("🏠 Risk Dashboard")
    st.write("Comprehensive overview of your portfolio's risk profile and key metrics.")
    
    # Check data availability
    data_status = {
        'Portfolio Data': st.session_state.portfolio_data is not None,
        'Market Data': st.session_state.market_data is not None,
        'Financial Data': st.session_state.company_financials is not None,
        'VaR Analysis': 'var_results' in st.session_state,
        'Z-Score Analysis': 'zscore_results' in st.session_state,
        'Stress Testing': 'stress_results' in st.session_state,
        'Scenario Analysis': 'scenario_results' in st.session_state
    }
    
    # Data status sidebar
    with st.sidebar:
        st.subheader("Analysis Status")
        for analysis, status in data_status.items():
            if status:
                st.success(f"✅ {analysis}")
            else:
                st.warning(f"⚠️ {analysis}")
    
    # Main dashboard content
    if not data_status['Portfolio Data']:
        st.warning("Please load portfolio data to view the risk dashboard.")
        st.info("Navigate to the 'Data Input' section to get started.")
        return
    
    # Calculate overall risk score
    overall_risk_score, risk_components = calculate_risk_score(
        st.session_state.portfolio_data,
        st.session_state.market_data,
        st.session_state.get('var_results'),
        st.session_state.get('zscore_results'),
        st.session_state.get('stress_results'),
        st.session_state.get('scenario_results')
    )
    
    # Overall Risk Score
    st.subheader("Overall Risk Assessment")
    
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        # Risk gauge
        risk_gauge = create_risk_gauge(
            overall_risk_score, 
            "Portfolio Risk Score",
            thresholds=[40, 70]
        )
        st.plotly_chart(risk_gauge, use_container_width=True)
    
    with col2:
        # Risk level interpretation
        if overall_risk_score < 40:
            st.success("**Low Risk**")
            risk_level = "Conservative portfolio with well-managed risk exposure."
        elif overall_risk_score < 70:
            st.warning("**Moderate Risk**")
            risk_level = "Balanced risk profile with some areas for improvement."
        else:
            st.error("**High Risk**")
            risk_level = "Elevated risk levels requiring immediate attention."
        
        st.write(risk_level)
    
    with col3:
        # Quick stats
        if st.session_state.portfolio_data is not None:
            num_holdings = len(st.session_state.portfolio_data)
            st.metric("Holdings", num_holdings)
        
        if 'var_results' in st.session_state:
            portfolio_value = st.session_state.var_results.get('portfolio_value', 0)
            st.metric("Portfolio Value", f"${portfolio_value:,.0f}")
    
    # Risk Component Breakdown
    if risk_components:
        st.subheader("Risk Component Analysis")
        
        # Risk components bar chart
        components_df = pd.DataFrame({
            'Component': list(risk_components.keys()),
            'Risk Score': list(risk_components.values())
        })
        
        fig_components = px.bar(
            components_df,
            x='Component',
            y='Risk Score',
            title='Risk Components Breakdown',
            color='Risk Score',
            color_continuous_scale='RdYlGn_r'
        )
        fig_components.update_layout(height=400)
        st.plotly_chart(fig_components, use_container_width=True)
    
    # Key Metrics Dashboard
    st.subheader("Key Risk Metrics")
    
    col1, col2, col3, col4 = st.columns(4)
    
    # VaR Metrics
    with col1:
        if 'var_results' in st.session_state:
            var_results = st.session_state.var_results
            parametric_var = var_results.get('parametric_var', 0)
            portfolio_value = var_results.get('portfolio_value', 1)
            var_pct = abs(parametric_var / portfolio_value) * 100
            
            st.metric(
                "VaR (95%)",
                f"${abs(parametric_var):,.0f}",
                f"{var_pct:.2f}%"
            )
        else:
            st.metric("VaR (95%)", "Not calculated", "Run VaR analysis")
    
    # Z-Score
    with col2:
        if 'zscore_results' in st.session_state:
            zscore_results = st.session_state.zscore_results
            z_score = zscore_results.get('z_score', 0)
            zone = zscore_results.get('zone', 'Unknown')
            
            st.metric(
                "Altman Z-Score",
                f"{z_score:.2f}",
                zone
            )
        else:
            st.metric("Altman Z-Score", "Not calculated", "Run Z-Score analysis")
    
    # Stress Test
    with col3:
        if 'stress_results' in st.session_state:
            stress_results = st.session_state.stress_results
            worst_scenario = min(stress_results.keys(), 
                               key=lambda k: stress_results[k]['total_impact'])
            worst_impact = stress_results[worst_scenario]['total_impact'] * 100
            
            st.metric(
                "Worst Stress Test",
                f"{worst_impact:.1f}%",
                worst_scenario
            )
        else:
            st.metric("Stress Test", "Not calculated", "Run stress tests")
    
    # Portfolio Volatility
    with col4:
        if 'asset_metrics' in st.session_state:
            # Calculate simple portfolio volatility
            asset_volatilities = st.session_state.asset_metrics['volatilities']
            portfolio_vol = np.mean(list(asset_volatilities.values())) * 100 if asset_volatilities else 0
            
            st.metric(
                "Avg Asset Volatility",
                f"{portfolio_vol:.1f}%",
                "Annualized"
            )
        else:
            st.metric("Portfolio Volatility", "Not calculated", "Run volatility analysis")
    
    # Market Environment
    st.subheader("Market Environment")
    
    if st.session_state.market_data:
        try:
            col1, col2, col3 = st.columns(3)
            
            # S&P 500 performance
            with col1:
                if '^GSPC' in st.session_state.market_data:
                    sp500_data = st.session_state.market_data['^GSPC']
                    current_price = sp500_data['Close'].iloc[-1]
                    prev_price = sp500_data['Close'].iloc[-22]  # ~1 month ago
                    monthly_return = (current_price - prev_price) / prev_price * 100
                    
                    st.metric(
                        "S&P 500 (1M)",
                        f"{current_price:.0f}",
                        f"{monthly_return:+.1f}%"
                    )
            
            # VIX level
            with col2:
                if '^VIX' in st.session_state.market_data:
                    vix_data = st.session_state.market_data['^VIX']
                    current_vix = vix_data['Close'].iloc[-1]
                    
                    if current_vix < 20:
                        vix_status = "Low"
                    elif current_vix < 30:
                        vix_status = "Moderate"
                    else:
                        vix_status = "High"
                    
                    st.metric(
                        "VIX Level",
                        f"{current_vix:.1f}",
                        vix_status
                    )
            
            # Risk-free rate
            with col3:
                risk_free_rate = st.session_state.market_data.get('risk_free_rate', 0.025) * 100
                st.metric(
                    "Risk-free Rate",
                    f"{risk_free_rate:.1f}%",
                    "Current"
                )
        
        except Exception as e:
            st.warning(f"Error displaying market data: {e}")
    
    # Recent Analysis Timeline
    st.subheader("Analysis Timeline")
    
    timeline_data = []
    
    # Check when each analysis was completed
    analyses = [
        ('Portfolio Data', 'portfolio_data'),
        ('Market Data', 'market_data'),
        ('VaR Analysis', 'var_results'),
        ('Altman Z-Score', 'zscore_results'),
        ('Stress Testing', 'stress_results'),
        ('Scenario Analysis', 'scenario_results'),
        ('Volatility Sizing', 'sizing_results')
    ]
    
    for analysis_name, session_key in analyses:
        if session_key in st.session_state:
            timeline_data.append({
                'Analysis': analysis_name,
                'Status': 'Completed',
                'Timestamp': datetime.now().strftime("%Y-%m-%d %H:%M")  # Simplified timestamp
            })
        else:
            timeline_data.append({
                'Analysis': analysis_name,
                'Status': 'Pending',
                'Timestamp': '-'
            })
    
    timeline_df = pd.DataFrame(timeline_data)
    st.dataframe(timeline_df, use_container_width=True)
    
    # Risk Alerts and Recommendations
    st.subheader("Risk Alerts & Recommendations")
    
    alerts = []
    
    # Generate alerts based on analysis results
    if 'var_results' in st.session_state:
        var_results = st.session_state.var_results
        var_pct = abs(var_results.get('parametric_var', 0)) / var_results.get('portfolio_value', 1)
        if var_pct > 0.1:  # More than 10% VaR
            alerts.append({
                'Type': 'High VaR',
                'Severity': 'Warning',
                'Message': f'Portfolio VaR exceeds 10% ({var_pct*100:.1f}%). Consider reducing risk exposure.'
            })
    
    if 'zscore_results' in st.session_state:
        zscore_results = st.session_state.zscore_results
        z_score = zscore_results.get('z_score', 3.0)
        if z_score < 1.8:
            alerts.append({
                'Type': 'Credit Risk',
                'Severity': 'Critical',
                'Message': f'Altman Z-Score ({z_score:.2f}) indicates high bankruptcy risk.'
            })
    
    if 'stress_results' in st.session_state:
        stress_results = st.session_state.stress_results
        worst_impact = min([v['total_impact'] for v in stress_results.values()])
        if worst_impact < -0.3:
            alerts.append({
                'Type': 'Stress Risk',
                'Severity': 'Warning',
                'Message': f'Portfolio vulnerable to extreme losses ({worst_impact*100:.1f}%) in stress scenarios.'
            })
    
    # Portfolio concentration check
    if st.session_state.portfolio_data is not None:
        weights = st.session_state.portfolio_data.get('Weight', [])
        if hasattr(weights, '__iter__') and len(weights) > 0:
            max_weight = max(weights)
            if max_weight > 0.4:
                alerts.append({
                    'Type': 'Concentration',
                    'Severity': 'Warning',
                    'Message': f'High concentration risk: largest position is {max_weight*100:.1f}% of portfolio.'
                })
    
    # Display alerts
    if alerts:
        for alert in alerts:
            if alert['Severity'] == 'Critical':
                st.error(f"🚨 **{alert['Type']}**: {alert['Message']}")
            elif alert['Severity'] == 'Warning':
                st.warning(f"⚠️ **{alert['Type']}**: {alert['Message']}")
            else:
                st.info(f"ℹ️ **{alert['Type']}**: {alert['Message']}")
    else:
        st.success("✅ No critical risk alerts at this time.")
    
    # Next Steps
    st.subheader("Recommended Next Steps")
    
    next_steps = []
    
    if not data_status['VaR Analysis']:
        next_steps.append("📈 Complete VaR analysis to understand downside risk")
    
    if not data_status['Z-Score Analysis']:
        next_steps.append("💰 Run Altman Z-Score analysis for credit risk assessment")
    
    if not data_status['Stress Testing']:
        next_steps.append("⚡ Perform stress testing to evaluate extreme scenarios")
    
    if overall_risk_score > 70:
        next_steps.append("🎯 Review portfolio allocation and consider risk reduction")
    
    if not next_steps:
        next_steps.append("📋 Generate comprehensive risk report")
        next_steps.append("🔄 Schedule regular risk monitoring and rebalancing")
    
    for step in next_steps:
        st.write(f"• {step}")
    
    # Refresh dashboard
    if st.button("🔄 Refresh Dashboard"):
        st.rerun()
