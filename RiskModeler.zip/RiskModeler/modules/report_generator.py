import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
from io import BytesIO
import base64

def generate_executive_summary():
    """Generate executive summary based on completed analyses"""
    summary = {}
    
    # Portfolio overview
    if st.session_state.portfolio_data is not None:
        portfolio_size = len(st.session_state.portfolio_data)
        total_value = 1000000  # Default value
        if 'var_results' in st.session_state:
            total_value = st.session_state.var_results.get('portfolio_value', 1000000)
        
        summary['portfolio'] = {
            'holdings': portfolio_size,
            'total_value': total_value,
            'analysis_date': datetime.now().strftime('%Y-%m-%d')
        }
    
    # Risk assessment
    risk_level = "Moderate"
    key_risks = []
    
    # VaR assessment
    if 'var_results' in st.session_state:
        var_results = st.session_state.var_results
        var_pct = abs(var_results.get('parametric_var', 0)) / var_results.get('portfolio_value', 1)
        
        if var_pct > 0.15:
            risk_level = "High"
            key_risks.append("High Value-at-Risk exposure")
        elif var_pct > 0.08:
            key_risks.append("Moderate VaR levels require monitoring")
        
        summary['var'] = {
            'var_95_pct': var_pct * 100,
            'confidence_level': var_results.get('confidence_level', 0.95) * 100
        }
    
    # Credit risk assessment
    if 'zscore_results' in st.session_state:
        zscore_results = st.session_state.zscore_results
        z_score = zscore_results.get('z_score', 2.0)
        
        if z_score < 1.8:
            risk_level = "High"
            key_risks.append("High bankruptcy risk indicated by Z-Score")
        elif z_score < 2.99:
            key_risks.append("Elevated credit risk requires attention")
        
        summary['credit'] = {
            'z_score': z_score,
            'risk_zone': zscore_results.get('zone', 'Unknown')
        }
    
    # Stress testing assessment
    if 'stress_results' in st.session_state:
        stress_results = st.session_state.stress_results
        worst_impact = min([v['total_impact'] for v in stress_results.values()])
        
        if worst_impact < -0.3:
            risk_level = "High"
            key_risks.append("Extreme vulnerability to stress scenarios")
        elif worst_impact < -0.2:
            key_risks.append("Moderate stress scenario vulnerability")
        
        summary['stress'] = {
            'worst_scenario_impact': worst_impact * 100,
            'scenarios_tested': len(stress_results)
        }
    
    summary['overall'] = {
        'risk_level': risk_level,
        'key_risks': key_risks,
        'recommendations': generate_recommendations(risk_level, key_risks)
    }
    
    return summary

def generate_recommendations(risk_level, key_risks):
    """Generate specific recommendations based on risk assessment"""
    recommendations = []
    
    if risk_level == "High":
        recommendations.extend([
            "Immediate portfolio review and restructuring required",
            "Consider reducing position sizes and increasing diversification",
            "Implement comprehensive hedging strategies",
            "Establish strict stop-loss mechanisms"
        ])
    elif risk_level == "Moderate":
        recommendations.extend([
            "Enhanced monitoring of risk metrics recommended",
            "Consider tactical allocation adjustments",
            "Review correlation exposures across holdings",
            "Implement gradual risk reduction measures"
        ])
    else:
        recommendations.extend([
            "Maintain current risk management framework",
            "Continue regular portfolio monitoring",
            "Consider opportunistic rebalancing"
        ])
    
    # Specific recommendations based on risk types
    for risk in key_risks:
        if "VaR" in risk:
            recommendations.append("Implement position sizing based on VaR limits")
        if "Z-Score" in risk or "bankruptcy" in risk:
            recommendations.append("Conduct detailed fundamental analysis of holdings")
        if "stress" in risk.lower():
            recommendations.append("Develop scenario-based hedging strategies")
    
    return recommendations

def create_risk_summary_chart(summary):
    """Create visual summary of risk metrics"""
    if not summary:
        return None
    
    # Create risk metrics radar chart
    categories = []
    values = []
    
    if 'var' in summary:
        categories.append('VaR Risk')
        var_pct = summary['var']['var_95_pct']
        # Convert to risk score (0-100, higher is worse)
        var_score = min(100, var_pct * 5)  # 20% VaR = 100 risk score
        values.append(var_score)
    
    if 'credit' in summary:
        categories.append('Credit Risk')
        z_score = summary['credit']['z_score']
        # Convert Z-score to risk score (inverted)
        if z_score >= 2.99:
            credit_score = 20
        elif z_score >= 1.8:
            credit_score = 60
        else:
            credit_score = 90
        values.append(credit_score)
    
    if 'stress' in summary:
        categories.append('Stress Risk')
        stress_impact = abs(summary['stress']['worst_scenario_impact'])
        # Convert to risk score
        stress_score = min(100, stress_impact * 3)  # 33% loss = 100 risk score
        values.append(stress_score)
    
    # Add concentration risk (simplified)
    if st.session_state.portfolio_data is not None:
        categories.append('Concentration Risk')
        weights = st.session_state.portfolio_data.get('Weight', [])
        if hasattr(weights, '__iter__') and len(weights) > 0:
            max_weight = max(weights)
            concentration_score = max_weight * 200  # 50% position = 100 risk score
            values.append(min(100, concentration_score))
        else:
            values.append(50)
    
    if categories and values:
        fig = go.Figure()
        
        fig.add_trace(go.Scatterpolar(
            r=values,
            theta=categories,
            fill='toself',
            name='Risk Profile',
            line_color='red'
        ))
        
        fig.update_layout(
            polar=dict(
                radialaxis=dict(
                    visible=True,
                    range=[0, 100]
                )
            ),
            title="Portfolio Risk Profile Overview",
            height=400
        )
        
        return fig
    
    return None

def generate_detailed_analysis():
    """Generate detailed analysis sections"""
    analysis = {}
    
    # VaR Analysis Detail
    if 'var_results' in st.session_state:
        var_results = st.session_state.var_results
        
        analysis['var_analysis'] = {
            'title': 'Value at Risk Analysis',
            'summary': f"Portfolio VaR at {var_results.get('confidence_level', 0.95)*100:.0f}% confidence level over {var_results.get('time_horizon', 1)} day(s)",
            'key_findings': [
                f"Parametric VaR: ${abs(var_results.get('parametric_var', 0)):,.0f}",
                f"Historical VaR: ${abs(var_results.get('historical_var', 0)):,.0f}" if 'historical_var' in var_results else None,
                f"Monte Carlo VaR: ${abs(var_results.get('monte_carlo_var', 0)):,.0f}" if 'monte_carlo_var' in var_results else None
            ],
            'recommendations': [
                "Monitor VaR limits daily",
                "Consider diversification if VaR exceeds risk budget",
                "Implement position sizing based on individual security VaR contributions"
            ]
        }
        
        # Remove None values
        analysis['var_analysis']['key_findings'] = [f for f in analysis['var_analysis']['key_findings'] if f is not None]
    
    # Z-Score Analysis Detail
    if 'zscore_results' in st.session_state:
        zscore_results = st.session_state.zscore_results
        z_score = zscore_results.get('z_score', 0)
        zone = zscore_results.get('zone', 'Unknown')
        
        analysis['zscore_analysis'] = {
            'title': 'Altman Z-Score Credit Analysis',
            'summary': f"Company bankruptcy risk assessment: {zone} (Z-Score: {z_score:.2f})",
            'key_findings': [
                f"Z-Score of {z_score:.2f} indicates {zscore_results.get('interpretation', 'unknown risk')}",
                f"Company falls in {zone}",
                "Analysis based on financial ratios and market data"
            ],
            'recommendations': []
        }
        
        if z_score < 1.8:
            analysis['zscore_analysis']['recommendations'].extend([
                "Immediate credit risk assessment required",
                "Consider reducing exposure to this entity",
                "Monitor financial statements closely"
            ])
        elif z_score < 2.99:
            analysis['zscore_analysis']['recommendations'].extend([
                "Enhanced monitoring recommended",
                "Review credit facilities and cash flow",
                "Consider hedging credit exposure"
            ])
        else:
            analysis['zscore_analysis']['recommendations'].extend([
                "Maintain current exposure levels",
                "Continue periodic monitoring",
                "Company shows financial strength"
            ])
    
    # Stress Testing Detail
    if 'stress_results' in st.session_state:
        stress_results = st.session_state.stress_results
        worst_scenario = min(stress_results.keys(), key=lambda k: stress_results[k]['total_impact'])
        worst_impact = stress_results[worst_scenario]['total_impact']
        
        analysis['stress_analysis'] = {
            'title': 'Stress Testing Results',
            'summary': f"Portfolio tested against {len(stress_results)} stress scenarios",
            'key_findings': [
                f"Worst case scenario: {worst_scenario}",
                f"Maximum potential loss: {abs(worst_impact)*100:.1f}%",
                f"Scenarios tested: {', '.join(list(stress_results.keys())[:3])}" + ("..." if len(stress_results) > 3 else "")
            ],
            'recommendations': []
        }
        
        if abs(worst_impact) > 0.3:
            analysis['stress_analysis']['recommendations'].extend([
                "Significant stress vulnerability identified",
                "Consider portfolio restructuring",
                "Implement comprehensive hedging program"
            ])
        elif abs(worst_impact) > 0.2:
            analysis['stress_analysis']['recommendations'].extend([
                "Moderate stress exposure",
                "Consider tactical hedging",
                "Monitor scenario probabilities"
            ])
        else:
            analysis['stress_analysis']['recommendations'].extend([
                "Acceptable stress test results",
                "Maintain current risk framework",
                "Continue scenario monitoring"
            ])
    
    # Scenario Analysis Detail
    if 'scenario_results' in st.session_state:
        scenario_results = st.session_state.scenario_results
        
        analysis['scenario_analysis'] = {
            'title': 'Historical Scenario Analysis',
            'summary': f"Portfolio performance during {scenario_results.get('scenario_name', 'historical crisis')}",
            'key_findings': [
                f"Portfolio impact: {scenario_results.get('portfolio_impact', 0)*100:.2f}%",
                f"Market return: {scenario_results.get('market_return', 0)*100:.2f}%",
                f"Relative performance: {(scenario_results.get('portfolio_impact', 0) - scenario_results.get('market_return', 0))*100:+.2f}%"
            ],
            'recommendations': [
                "Review correlation patterns during crisis periods",
                "Consider crisis-period hedging strategies",
                "Analyze factor exposures during stress"
            ]
        }
    
    return analysis

def show_report_generator():
    st.header("📋 Risk Report Generator")
    
    st.subheader("Comprehensive Risk Analysis Report")
    st.write("""
    Generate detailed risk reports with executive summaries, technical analysis, and actionable recommendations
    based on your completed risk analyses.
    """)
    
    # Check available analyses
    available_analyses = {
        'Portfolio Data': st.session_state.portfolio_data is not None,
        'Market Data': st.session_state.market_data is not None,
        'VaR Analysis': 'var_results' in st.session_state,
        'Altman Z-Score': 'zscore_results' in st.session_state,
        'Stress Testing': 'stress_results' in st.session_state,
        'Scenario Analysis': 'scenario_results' in st.session_state,
        'Volatility Sizing': 'sizing_results' in st.session_state
    }
    
    # Display analysis status
    st.subheader("Analysis Completion Status")
    
    col1, col2 = st.columns(2)
    
    with col1:
        for analysis, completed in list(available_analyses.items())[:4]:
            if completed:
                st.success(f"✅ {analysis}")
            else:
                st.warning(f"⚠️ {analysis}")
    
    with col2:
        for analysis, completed in list(available_analyses.items())[4:]:
            if completed:
                st.success(f"✅ {analysis}")
            else:
                st.warning(f"⚠️ {analysis}")
    
    # Report configuration
    st.subheader("Report Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        report_title = st.text_input("Report Title", value="Portfolio Risk Analysis Report")
        report_date = st.date_input("Report Date", value=datetime.now().date())
    
    with col2:
        include_charts = st.checkbox("Include Charts and Visualizations", value=True)
        include_recommendations = st.checkbox("Include Recommendations", value=True)
    
    # Report sections selection
    st.write("**Select Report Sections:**")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        include_executive = st.checkbox("Executive Summary", value=True)
        include_portfolio = st.checkbox("Portfolio Overview", value=True)
        include_var = st.checkbox("VaR Analysis", value='var_results' in st.session_state)
    
    with col2:
        include_zscore = st.checkbox("Credit Risk Analysis", value='zscore_results' in st.session_state)
        include_stress = st.checkbox("Stress Testing", value='stress_results' in st.session_state)
        include_scenario = st.checkbox("Scenario Analysis", value='scenario_results' in st.session_state)
    
    with col3:
        include_volatility = st.checkbox("Volatility Analysis", value='sizing_results' in st.session_state)
        include_market = st.checkbox("Market Environment", value=st.session_state.market_data is not None)
        include_appendix = st.checkbox("Technical Appendix", value=True)
    
    # Generate report
    if st.button("Generate Risk Report", type="primary"):
        if not available_analyses['Portfolio Data']:
            st.error("Portfolio data is required to generate a report.")
            return
        
        with st.spinner("Generating comprehensive risk report..."):
            
            # Generate executive summary
            executive_summary = generate_executive_summary()
            detailed_analysis = generate_detailed_analysis()
            
            # Display report
            st.markdown("---")
            st.header(f"📊 {report_title}")
            st.write(f"**Report Date:** {report_date}")
            st.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            
            # Executive Summary
            if include_executive and executive_summary:
                st.header("Executive Summary")
                
                # Overall assessment
                if 'overall' in executive_summary:
                    overall = executive_summary['overall']
                    
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        risk_level = overall['risk_level']
                        if risk_level == "High":
                            st.error(f"**Risk Level:** {risk_level}")
                        elif risk_level == "Moderate":
                            st.warning(f"**Risk Level:** {risk_level}")
                        else:
                            st.success(f"**Risk Level:** {risk_level}")
                    
                    with col2:
                        if 'portfolio' in executive_summary:
                            portfolio = executive_summary['portfolio']
                            st.metric("Portfolio Holdings", portfolio['holdings'])
                    
                    with col3:
                        if 'portfolio' in executive_summary:
                            st.metric("Portfolio Value", f"${portfolio['total_value']:,.0f}")
                
                # Key risks
                if overall['key_risks']:
                    st.write("**Key Risk Factors:**")
                    for risk in overall['key_risks']:
                        st.write(f"• {risk}")
                else:
                    st.success("No significant risk factors identified.")
                
                # Risk profile chart
                if include_charts:
                    risk_chart = create_risk_summary_chart(executive_summary)
                    if risk_chart:
                        st.plotly_chart(risk_chart, use_container_width=True)
            
            # Portfolio Overview
            if include_portfolio and st.session_state.portfolio_data is not None:
                st.header("Portfolio Overview")
                
                portfolio_df = st.session_state.portfolio_data.copy()
                
                # Portfolio composition
                st.subheader("Portfolio Composition")
                st.dataframe(portfolio_df, use_container_width=True)
                
                if include_charts and len(portfolio_df) > 0:
                    # Portfolio allocation pie chart
                    if 'Weight' in portfolio_df.columns:
                        fig_pie = px.pie(
                            portfolio_df,
                            values='Weight',
                            names='Symbol',
                            title='Portfolio Allocation'
                        )
                        st.plotly_chart(fig_pie, use_container_width=True)
            
            # VaR Analysis
            if include_var and 'var_analysis' in detailed_analysis:
                st.header("Value at Risk Analysis")
                
                var_analysis = detailed_analysis['var_analysis']
                st.write(var_analysis['summary'])
                
                st.subheader("Key Findings")
                for finding in var_analysis['key_findings']:
                    st.write(f"• {finding}")
                
                if include_recommendations and var_analysis['recommendations']:
                    st.subheader("VaR Recommendations")
                    for rec in var_analysis['recommendations']:
                        st.write(f"• {rec}")
            
            # Credit Risk Analysis
            if include_zscore and 'zscore_analysis' in detailed_analysis:
                st.header("Credit Risk Analysis")
                
                zscore_analysis = detailed_analysis['zscore_analysis']
                st.write(zscore_analysis['summary'])
                
                st.subheader("Key Findings")
                for finding in zscore_analysis['key_findings']:
                    st.write(f"• {finding}")
                
                if include_recommendations and zscore_analysis['recommendations']:
                    st.subheader("Credit Risk Recommendations")
                    for rec in zscore_analysis['recommendations']:
                        st.write(f"• {rec}")
            
            # Stress Testing
            if include_stress and 'stress_analysis' in detailed_analysis:
                st.header("Stress Testing Results")
                
                stress_analysis = detailed_analysis['stress_analysis']
                st.write(stress_analysis['summary'])
                
                st.subheader("Key Findings")
                for finding in stress_analysis['key_findings']:
                    st.write(f"• {finding}")
                
                if include_recommendations and stress_analysis['recommendations']:
                    st.subheader("Stress Testing Recommendations")
                    for rec in stress_analysis['recommendations']:
                        st.write(f"• {rec}")
            
            # Scenario Analysis
            if include_scenario and 'scenario_analysis' in detailed_analysis:
                st.header("Historical Scenario Analysis")
                
                scenario_analysis = detailed_analysis['scenario_analysis']
                st.write(scenario_analysis['summary'])
                
                st.subheader("Key Findings")
                for finding in scenario_analysis['key_findings']:
                    st.write(f"• {finding}")
                
                if include_recommendations and scenario_analysis['recommendations']:
                    st.subheader("Scenario Analysis Recommendations")
                    for rec in scenario_analysis['recommendations']:
                        st.write(f"• {rec}")
            
            # Market Environment
            if include_market and st.session_state.market_data:
                st.header("Market Environment Assessment")
                
                try:
                    col1, col2, col3 = st.columns(3)
                    
                    # S&P 500
                    with col1:
                        if '^GSPC' in st.session_state.market_data:
                            sp500_data = st.session_state.market_data['^GSPC']
                            current_price = sp500_data['Close'].iloc[-1]
                            st.metric("S&P 500", f"{current_price:.0f}")
                    
                    # VIX
                    with col2:
                        if '^VIX' in st.session_state.market_data:
                            vix_data = st.session_state.market_data['^VIX']
                            current_vix = vix_data['Close'].iloc[-1]
                            st.metric("VIX Level", f"{current_vix:.1f}")
                    
                    # Risk-free rate
                    with col3:
                        risk_free_rate = st.session_state.market_data.get('risk_free_rate', 0.025) * 100
                        st.metric("Risk-free Rate", f"{risk_free_rate:.1f}%")
                
                except Exception as e:
                    st.warning(f"Error displaying market environment: {e}")
            
            # Overall Recommendations
            if include_recommendations and executive_summary and 'overall' in executive_summary:
                st.header("Strategic Recommendations")
                
                overall_recs = executive_summary['overall']['recommendations']
                
                st.subheader("Immediate Actions")
                immediate_actions = [rec for rec in overall_recs if any(word in rec.lower() 
                                   for word in ['immediate', 'urgent', 'now', 'stop'])]
                
                if immediate_actions:
                    for action in immediate_actions:
                        st.error(f"🚨 {action}")
                
                st.subheader("Medium-term Strategies")
                medium_term = [rec for rec in overall_recs if rec not in immediate_actions and 
                             any(word in rec.lower() for word in ['consider', 'review', 'monitor', 'enhance'])]
                
                if medium_term:
                    for strategy in medium_term:
                        st.warning(f"⚠️ {strategy}")
                
                st.subheader("Long-term Considerations")
                long_term = [rec for rec in overall_recs if rec not in immediate_actions and rec not in medium_term]
                
                if long_term:
                    for consideration in long_term:
                        st.info(f"ℹ️ {consideration}")
            
            # Technical Appendix
            if include_appendix:
                st.header("Technical Appendix")
                
                st.subheader("Methodology Notes")
                st.write("""
                **Value at Risk (VaR):**
                - Parametric VaR assumes normal distribution of returns
                - Historical VaR uses empirical distribution of past returns
                - Monte Carlo VaR simulates future scenarios using statistical modeling
                
                **Altman Z-Score:**
                - Formula: 1.2×(WC/TA) + 1.4×(RE/TA) + 3.3×(EBIT/TA) + 0.6×(MC/TL) + 1.0×(S/TA)
                - Safe Zone: Z > 2.99, Grey Zone: 1.8 < Z < 2.99, Distress Zone: Z < 1.8
                
                **Stress Testing:**
                - Scenarios based on historical market events and expert judgment
                - Asset type classifications determine scenario impact factors
                - Results show potential portfolio losses under extreme conditions
                """)
                
                st.subheader("Data Sources and Limitations")
                st.write("""
                - Market data sourced from Yahoo Finance API
                - Financial data may have reporting delays
                - Historical scenarios based on past events may not predict future performance
                - Risk models assume certain statistical distributions that may not hold in practice
                """)
            
            # Report summary
            st.markdown("---")
            st.subheader("Report Generation Summary")
            
            sections_included = []
            if include_executive: sections_included.append("Executive Summary")
            if include_portfolio: sections_included.append("Portfolio Overview")
            if include_var: sections_included.append("VaR Analysis")
            if include_zscore: sections_included.append("Credit Risk Analysis")
            if include_stress: sections_included.append("Stress Testing")
            if include_scenario: sections_included.append("Scenario Analysis")
            if include_market: sections_included.append("Market Environment")
            if include_recommendations: sections_included.append("Recommendations")
            if include_appendix: sections_included.append("Technical Appendix")
            
            st.write(f"**Sections Included:** {', '.join(sections_included)}")
            st.write(f"**Charts Included:** {'Yes' if include_charts else 'No'}")
            st.write(f"**Total Analyses:** {sum(available_analyses.values())}/{len(available_analyses)}")
            
            st.success("✅ Risk report generated successfully!")
            
            # Export options
            st.subheader("Export Options")
            
            col1, col2 = st.columns(2)
            
            with col1:
                if st.button("📧 Email Report"):
                    st.info("Email functionality would be implemented with SMTP integration")
            
            with col2:
                if st.button("💾 Save Report Data"):
                    # Save report data to session state for potential export
                    st.session_state.generated_report = {
                        'title': report_title,
                        'date': str(report_date),
                        'executive_summary': executive_summary,
                        'detailed_analysis': detailed_analysis,
                        'sections_included': sections_included
                    }
                    st.success("Report data saved to session!")
    
    # Report history/templates
    st.markdown("---")
    st.subheader("Report Templates & History")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Quick Templates:**")
        if st.button("🔥 High-Risk Portfolio Report"):
            st.info("Pre-configured template for high-risk portfolios")
        
        if st.button("📈 Standard Risk Report"):
            st.info("Comprehensive report with all standard sections")
        
        if st.button("⚡ Executive Summary Only"):
            st.info("Condensed report for executive review")
    
    with col2:
        st.write("**Report History:**")
        if 'generated_report' in st.session_state:
            last_report = st.session_state.generated_report
            st.write(f"**Last Generated:** {last_report['title']}")
            st.write(f"**Date:** {last_report['date']}")
            
            if st.button("🔄 Regenerate Last Report"):
                st.info("Feature to regenerate previous report configuration")
        else:
            st.write("No reports generated yet.")
