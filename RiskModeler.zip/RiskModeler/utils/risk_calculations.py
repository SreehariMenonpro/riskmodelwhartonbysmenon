import numpy as np
import pandas as pd
import streamlit as st
from scipy import stats, optimize
from typing import Dict, List, Optional, Tuple, Union
import warnings
warnings.filterwarnings('ignore')

def calculate_portfolio_returns(portfolio_data: pd.DataFrame, market_data: Dict[str, pd.DataFrame]) -> Optional[np.ndarray]:
    """Calculate portfolio returns based on holdings and market data"""
    try:
        if portfolio_data is None or market_data is None:
            return None
        
        portfolio_returns = []
        dates = None
        
        # Get all available dates from market data
        all_dates = set()
        for symbol in portfolio_data['Symbol']:
            if symbol in market_data:
                all_dates.update(market_data[symbol].index)
        
        if not all_dates:
            return None
        
        # Sort dates
        sorted_dates = sorted(all_dates)
        
        # Calculate returns for each date
        for i, date in enumerate(sorted_dates[1:], 1):  # Start from second date
            prev_date = sorted_dates[i-1]
            daily_return = 0.0
            total_weight = 0.0
            
            for _, holding in portfolio_data.iterrows():
                symbol = holding['Symbol']
                weight = holding.get('Weight', 0)
                
                if symbol in market_data and not market_data[symbol].empty:
                    price_data = market_data[symbol]
                    
                    # Get prices for current and previous date
                    if date in price_data.index and prev_date in price_data.index:
                        current_price = price_data.loc[date, 'Close']
                        prev_price = price_data.loc[prev_date, 'Close']
                        
                        if prev_price > 0:
                            security_return = (current_price - prev_price) / prev_price
                            daily_return += weight * security_return
                            total_weight += weight
            
            if total_weight > 0:
                portfolio_returns.append(daily_return / total_weight)
        
        return np.array(portfolio_returns) if portfolio_returns else None
    
    except Exception as e:
        st.error(f"Error calculating portfolio returns: {e}")
        return None

def monte_carlo_simulation(returns: np.ndarray, num_simulations: int, 
                         time_horizon: int, distribution: str = "Normal") -> np.ndarray:
    """Run Monte Carlo simulation for portfolio returns"""
    try:
        if returns is None or len(returns) == 0:
            return np.array([])
        
        # Calculate parameters
        mean_return = np.mean(returns)
        std_return = np.std(returns)
        
        simulated_returns = []
        
        for _ in range(num_simulations):
            if distribution == "Normal":
                # Generate random returns from normal distribution
                random_returns = np.random.normal(mean_return, std_return, time_horizon)
            elif distribution == "t-Distribution":
                # Fit t-distribution to data
                df, loc, scale = stats.t.fit(returns)
                random_returns = stats.t.rvs(df, loc=loc, scale=scale, size=time_horizon)
            else:
                # Default to normal
                random_returns = np.random.normal(mean_return, std_return, time_horizon)
            
            # Calculate cumulative return for the time horizon
            cumulative_return = np.sum(random_returns)
            simulated_returns.append(cumulative_return)
        
        return np.array(simulated_returns)
    
    except Exception as e:
        st.error(f"Error in Monte Carlo simulation: {e}")
        return np.array([])

def calculate_var(returns: np.ndarray, confidence_level: float = 0.95, 
                  method: str = "historical") -> Dict[str, float]:
    """Calculate Value at Risk using different methods"""
    try:
        if returns is None or len(returns) == 0:
            return {}
        
        results = {}
        
        # Historical VaR
        if method in ["historical", "all"]:
            sorted_returns = np.sort(returns)
            var_index = int((1 - confidence_level) * len(sorted_returns))
            results['historical_var'] = sorted_returns[var_index] if var_index < len(sorted_returns) else sorted_returns[0]
            
            # Expected Shortfall (CVaR)
            results['expected_shortfall'] = np.mean(sorted_returns[:var_index+1])
        
        # Parametric VaR
        if method in ["parametric", "all"]:
            mean_return = np.mean(returns)
            std_return = np.std(returns)
            z_score = stats.norm.ppf(1 - confidence_level)
            results['parametric_var'] = mean_return + z_score * std_return
        
        # Modified Cornish-Fisher VaR (accounts for skewness and kurtosis)
        if method in ["cornish_fisher", "all"]:
            mean_return = np.mean(returns)
            std_return = np.std(returns)
            skewness = stats.skew(returns)
            kurt = stats.kurtosis(returns, fisher=True)
            
            z = stats.norm.ppf(1 - confidence_level)
            z_cf = (z + 
                   (z**2 - 1) * skewness / 6 + 
                   (z**3 - 3*z) * kurt / 24 - 
                   (2*z**3 - 5*z) * skewness**2 / 36)
            
            results['cornish_fisher_var'] = mean_return + z_cf * std_return
        
        return results
    
    except Exception as e:
        st.error(f"Error calculating VaR: {e}")
        return {}

def calculate_expected_shortfall(returns: np.ndarray, confidence_level: float = 0.95) -> float:
    """Calculate Expected Shortfall (Conditional VaR)"""
    try:
        if returns is None or len(returns) == 0:
            return 0.0
        
        sorted_returns = np.sort(returns)
        var_index = int((1 - confidence_level) * len(sorted_returns))
        
        return np.mean(sorted_returns[:var_index+1])
    
    except Exception as e:
        st.error(f"Error calculating Expected Shortfall: {e}")
        return 0.0

def calculate_beta(asset_returns: np.ndarray, market_returns: np.ndarray) -> float:
    """Calculate beta coefficient"""
    try:
        if len(asset_returns) != len(market_returns) or len(asset_returns) == 0:
            return 1.0
        
        # Align returns
        min_length = min(len(asset_returns), len(market_returns))
        asset_returns = asset_returns[:min_length]
        market_returns = market_returns[:min_length]
        
        covariance = np.cov(asset_returns, market_returns)[0, 1]
        market_variance = np.var(market_returns)
        
        if market_variance == 0:
            return 1.0
        
        return covariance / market_variance
    
    except Exception as e:
        st.error(f"Error calculating beta: {e}")
        return 1.0

def calculate_correlation_matrix(returns_dict: Dict[str, np.ndarray]) -> pd.DataFrame:
    """Calculate correlation matrix for multiple return series"""
    try:
        if not returns_dict:
            return pd.DataFrame()
        
        # Find common length
        min_length = min(len(returns) for returns in returns_dict.values())
        
        # Truncate all return series to common length
        aligned_returns = {}
        for symbol, returns in returns_dict.items():
            aligned_returns[symbol] = returns[:min_length]
        
        # Create DataFrame and calculate correlation
        returns_df = pd.DataFrame(aligned_returns)
        correlation_matrix = returns_df.corr()
        
        return correlation_matrix
    
    except Exception as e:
        st.error(f"Error calculating correlation matrix: {e}")
        return pd.DataFrame()

def calculate_portfolio_volatility(weights: np.ndarray, cov_matrix: np.ndarray) -> float:
    """Calculate portfolio volatility given weights and covariance matrix"""
    try:
        if weights is None or cov_matrix is None:
            return 0.0
        
        portfolio_variance = np.dot(weights, np.dot(cov_matrix, weights))
        return np.sqrt(portfolio_variance)
    
    except Exception as e:
        st.error(f"Error calculating portfolio volatility: {e}")
        return 0.0

def calculate_tracking_error(portfolio_returns: np.ndarray, benchmark_returns: np.ndarray) -> float:
    """Calculate tracking error between portfolio and benchmark"""
    try:
        if len(portfolio_returns) != len(benchmark_returns) or len(portfolio_returns) == 0:
            return 0.0
        
        active_returns = portfolio_returns - benchmark_returns
        return np.std(active_returns) * np.sqrt(252)  # Annualized
    
    except Exception as e:
        st.error(f"Error calculating tracking error: {e}")
        return 0.0

def calculate_information_ratio(portfolio_returns: np.ndarray, benchmark_returns: np.ndarray) -> float:
    """Calculate information ratio"""
    try:
        if len(portfolio_returns) != len(benchmark_returns) or len(portfolio_returns) == 0:
            return 0.0
        
        active_returns = portfolio_returns - benchmark_returns
        active_return = np.mean(active_returns) * 252  # Annualized
        tracking_error = np.std(active_returns) * np.sqrt(252)  # Annualized
        
        if tracking_error == 0:
            return 0.0
        
        return active_return / tracking_error
    
    except Exception as e:
        st.error(f"Error calculating information ratio: {e}")
        return 0.0

def calculate_downside_deviation(returns: np.ndarray, target_return: float = 0) -> float:
    """Calculate downside deviation"""
    try:
        if returns is None or len(returns) == 0:
            return 0.0
        
        downside_returns = returns[returns < target_return] - target_return
        
        if len(downside_returns) == 0:
            return 0.0
        
        return np.sqrt(np.mean(downside_returns**2))
    
    except Exception as e:
        st.error(f"Error calculating downside deviation: {e}")
        return 0.0

def calculate_sortino_ratio(returns: np.ndarray, target_return: float = 0, 
                          risk_free_rate: float = 0) -> float:
    """Calculate Sortino ratio"""
    try:
        if returns is None or len(returns) == 0:
            return 0.0
        
        excess_returns = np.mean(returns) - risk_free_rate
        downside_deviation = calculate_downside_deviation(returns, target_return)
        
        if downside_deviation == 0:
            return 0.0
        
        return excess_returns / downside_deviation
    
    except Exception as e:
        st.error(f"Error calculating Sortino ratio: {e}")
        return 0.0

def calculate_calmar_ratio(returns: np.ndarray) -> float:
    """Calculate Calmar ratio (annual return / max drawdown)"""
    try:
        if returns is None or len(returns) == 0:
            return 0.0
        
        annual_return = np.mean(returns) * 252
        
        # Calculate max drawdown
        cumulative_returns = np.cumprod(1 + returns)
        running_max = np.maximum.accumulate(cumulative_returns)
        drawdowns = (cumulative_returns - running_max) / running_max
        max_drawdown = abs(np.min(drawdowns))
        
        if max_drawdown == 0:
            return 0.0
        
        return annual_return / max_drawdown
    
    except Exception as e:
        st.error(f"Error calculating Calmar ratio: {e}")
        return 0.0

def calculate_omega_ratio(returns: np.ndarray, threshold: float = 0) -> float:
    """Calculate Omega ratio"""
    try:
        if returns is None or len(returns) == 0:
            return 1.0
        
        excess_returns = returns - threshold
        gains = excess_returns[excess_returns > 0]
        losses = excess_returns[excess_returns <= 0]
        
        if len(losses) == 0:
            return float('inf')
        
        gain_sum = np.sum(gains) if len(gains) > 0 else 0
        loss_sum = abs(np.sum(losses))
        
        if loss_sum == 0:
            return float('inf')
        
        return gain_sum / loss_sum
    
    except Exception as e:
        st.error(f"Error calculating Omega ratio: {e}")
        return 1.0

def calculate_var_backtesting(returns: np.ndarray, var_estimates: np.ndarray, 
                            confidence_level: float = 0.95) -> Dict[str, float]:
    """Perform VaR backtesting"""
    try:
        if returns is None or var_estimates is None or len(returns) != len(var_estimates):
            return {}
        
        # Count violations (returns worse than VaR)
        violations = np.sum(returns < var_estimates)
        total_observations = len(returns)
        
        # Expected violations
        expected_violations = total_observations * (1 - confidence_level)
        
        # Violation rate
        violation_rate = violations / total_observations
        expected_rate = 1 - confidence_level
        
        # Kupiec test statistic
        if violations == 0 or violations == total_observations:
            kupiec_stat = 0
        else:
            likelihood_ratio = -2 * np.log(
                ((expected_rate**violations) * ((1-expected_rate)**(total_observations-violations))) /
                ((violation_rate**violations) * ((1-violation_rate)**(total_observations-violations)))
            )
            kupiec_stat = likelihood_ratio
        
        # Critical value for 95% confidence
        critical_value = 3.841  # Chi-squared with 1 df at 95% confidence
        
        return {
            'violations': violations,
            'violation_rate': violation_rate,
            'expected_rate': expected_rate,
            'kupiec_statistic': kupiec_stat,
            'test_passed': kupiec_stat < critical_value
        }
    
    except Exception as e:
        st.error(f"Error in VaR backtesting: {e}")
        return {}

def calculate_risk_adjusted_return(returns: np.ndarray, risk_free_rate: float = 0) -> Dict[str, float]:
    """Calculate various risk-adjusted return metrics"""
    try:
        if returns is None or len(returns) == 0:
            return {}
        
        metrics = {}
        
        # Basic statistics
        annual_return = np.mean(returns) * 252
        annual_volatility = np.std(returns) * np.sqrt(252)
        
        # Sharpe ratio
        excess_return = annual_return - risk_free_rate
        metrics['sharpe_ratio'] = excess_return / annual_volatility if annual_volatility > 0 else 0
        
        # Sortino ratio
        metrics['sortino_ratio'] = calculate_sortino_ratio(returns, risk_free_rate=risk_free_rate)
        
        # Calmar ratio
        metrics['calmar_ratio'] = calculate_calmar_ratio(returns)
        
        # Omega ratio
        metrics['omega_ratio'] = calculate_omega_ratio(returns)
        
        return metrics
    
    except Exception as e:
        st.error(f"Error calculating risk-adjusted returns: {e}")
        return {}

def optimize_portfolio_weights(expected_returns: np.ndarray, cov_matrix: np.ndarray, 
                             risk_aversion: float = 1.0, 
                             constraints: Optional[Dict] = None) -> np.ndarray:
    """Optimize portfolio weights using mean-variance optimization"""
    try:
        n_assets = len(expected_returns)
        
        # Objective function (negative utility)
        def objective(weights):
            portfolio_return = np.dot(weights, expected_returns)
            portfolio_variance = np.dot(weights, np.dot(cov_matrix, weights))
            utility = portfolio_return - 0.5 * risk_aversion * portfolio_variance
            return -utility  # Minimize negative utility
        
        # Constraints
        cons = [{'type': 'eq', 'fun': lambda x: np.sum(x) - 1}]  # Weights sum to 1
        
        # Add custom constraints if provided
        if constraints:
            if 'min_weight' in constraints:
                cons.append({'type': 'ineq', 'fun': lambda x: x - constraints['min_weight']})
            if 'max_weight' in constraints:
                cons.append({'type': 'ineq', 'fun': lambda x: constraints['max_weight'] - x})
        
        # Bounds (0 <= weight <= 1 for each asset)
        bounds = tuple((0, 1) for _ in range(n_assets))
        
        # Initial guess (equal weights)
        x0 = np.array([1.0 / n_assets] * n_assets)
        
        # Optimize
        result = optimize.minimize(objective, x0, method='SLSQP', bounds=bounds, constraints=cons)
        
        if result.success:
            return result.x
        else:
            st.warning("Portfolio optimization did not converge, returning equal weights")
            return x0
    
    except Exception as e:
        st.error(f"Error in portfolio optimization: {e}")
        return np.array([1.0 / len(expected_returns)] * len(expected_returns))

def calculate_component_var(weights: np.ndarray, cov_matrix: np.ndarray, 
                           confidence_level: float = 0.95) -> np.ndarray:
    """Calculate component VaR for each asset"""
    try:
        portfolio_variance = np.dot(weights, np.dot(cov_matrix, weights))
        portfolio_volatility = np.sqrt(portfolio_variance)
        
        # Marginal VaR
        marginal_var = np.dot(cov_matrix, weights) / portfolio_volatility
        
        # Component VaR
        component_var = weights * marginal_var
        
        # Scale by confidence level
        z_score = abs(stats.norm.ppf(1 - confidence_level))
        component_var *= z_score
        
        return component_var
    
    except Exception as e:
        st.error(f"Error calculating component VaR: {e}")
        return np.zeros(len(weights))

def calculate_incremental_var(weights: np.ndarray, cov_matrix: np.ndarray, 
                             asset_index: int, delta_weight: float = 0.01,
                             confidence_level: float = 0.95) -> float:
    """Calculate incremental VaR for a specific asset"""
    try:
        # Original portfolio VaR
        original_var = np.sqrt(np.dot(weights, np.dot(cov_matrix, weights)))
        
        # Modified weights
        modified_weights = weights.copy()
        modified_weights[asset_index] += delta_weight
        
        # Normalize weights
        modified_weights /= np.sum(modified_weights)
        
        # New portfolio VaR
        new_var = np.sqrt(np.dot(modified_weights, np.dot(cov_matrix, modified_weights)))
        
        # Incremental VaR
        incremental_var = new_var - original_var
        
        # Scale by confidence level
        z_score = abs(stats.norm.ppf(1 - confidence_level))
        incremental_var *= z_score
        
        return incremental_var
    
    except Exception as e:
        st.error(f"Error calculating incremental VaR: {e}")
        return 0.0
