import pandas as pd
import numpy as np
import yfinance as yf
from datetime import datetime, timedelta
import streamlit as st
from typing import Dict, List, Optional, Tuple, Union
import warnings
warnings.filterwarnings('ignore')

class DataLoader:
    """Utility class for loading and processing financial data"""
    
    def __init__(self):
        self.cache_duration = 3600  # 1 hour cache
    
    @st.cache_data(ttl=3600)
    def load_market_data(self, symbols: List[str], start_date: str, end_date: str) -> Dict[str, pd.DataFrame]:
        """Load market data for given symbols and date range"""
        market_data = {}
        
        for symbol in symbols:
            try:
                ticker = yf.Ticker(symbol)
                data = ticker.history(start=start_date, end=end_date)
                
                if not data.empty:
                    # Clean data
                    data = data.dropna()
                    market_data[symbol] = data
                else:
                    st.warning(f"No data available for {symbol}")
            
            except Exception as e:
                st.error(f"Error loading data for {symbol}: {e}")
                continue
        
        return market_data
    
    @st.cache_data(ttl=3600)
    def load_company_financials(self, symbol: str) -> Dict[str, any]:
        """Load company financial data from yfinance"""
        try:
            ticker = yf.Ticker(symbol)
            
            # Get financial statements
            balance_sheet = ticker.balance_sheet
            income_statement = ticker.financials
            info = ticker.info
            
            # Extract key metrics
            financial_data = {
                'symbol': symbol,
                'market_cap': info.get('marketCap', 0),
                'enterprise_value': info.get('enterpriseValue', 0),
                'revenue': 0,
                'ebit': 0,
                'total_assets': 0,
                'total_liabilities': 0,
                'working_capital': 0,
                'retained_earnings': 0,
                'total_equity': 0
            }
            
            # Extract from income statement (most recent quarter)
            if not income_statement.empty:
                latest_income = income_statement.iloc[:, 0]
                financial_data['revenue'] = latest_income.get('Total Revenue', 0)
                financial_data['ebit'] = latest_income.get('EBIT', 0)
            
            # Extract from balance sheet (most recent quarter)
            if not balance_sheet.empty:
                latest_bs = balance_sheet.iloc[:, 0]
                financial_data['total_assets'] = latest_bs.get('Total Assets', 0)
                financial_data['total_liabilities'] = latest_bs.get('Total Liab', 0)
                financial_data['total_equity'] = latest_bs.get('Stockholders Equity', 0)
                financial_data['retained_earnings'] = latest_bs.get('Retained Earnings', 0)
                
                # Calculate working capital
                current_assets = latest_bs.get('Current Assets', 0)
                current_liabilities = latest_bs.get('Current Liabilities', 0)
                financial_data['working_capital'] = current_assets - current_liabilities
            
            return financial_data
        
        except Exception as e:
            st.error(f"Error loading financial data for {symbol}: {e}")
            return None
    
    def validate_portfolio_data(self, portfolio_df: pd.DataFrame) -> Tuple[bool, List[str]]:
        """Validate portfolio data format and content"""
        errors = []
        
        # Check required columns
        required_columns = ['Symbol', 'Shares', 'Price', 'Weight']
        missing_columns = [col for col in required_columns if col not in portfolio_df.columns]
        
        if missing_columns:
            errors.append(f"Missing required columns: {', '.join(missing_columns)}")
        
        # Check for empty data
        if portfolio_df.empty:
            errors.append("Portfolio data is empty")
        
        # Check for negative values
        for col in ['Shares', 'Price', 'Weight']:
            if col in portfolio_df.columns:
                if (portfolio_df[col] < 0).any():
                    errors.append(f"Negative values found in {col} column")
        
        # Check weight sum
        if 'Weight' in portfolio_df.columns:
            weight_sum = portfolio_df['Weight'].sum()
            if abs(weight_sum - 1.0) > 0.01:  # Allow 1% tolerance
                errors.append(f"Portfolio weights sum to {weight_sum:.3f}, should sum to 1.0")
        
        # Check for duplicate symbols
        if 'Symbol' in portfolio_df.columns:
            if portfolio_df['Symbol'].duplicated().any():
                errors.append("Duplicate symbols found in portfolio")
        
        return len(errors) == 0, errors
    
    def clean_portfolio_data(self, portfolio_df: pd.DataFrame) -> pd.DataFrame:
        """Clean and normalize portfolio data"""
        cleaned_df = portfolio_df.copy()
        
        # Remove rows with missing symbols
        cleaned_df = cleaned_df.dropna(subset=['Symbol'])
        
        # Convert symbols to uppercase
        cleaned_df['Symbol'] = cleaned_df['Symbol'].str.upper().str.strip()
        
        # Ensure numeric columns are numeric
        numeric_columns = ['Shares', 'Price', 'Weight']
        for col in numeric_columns:
            if col in cleaned_df.columns:
                cleaned_df[col] = pd.to_numeric(cleaned_df[col], errors='coerce')
        
        # Remove rows with invalid numeric data
        cleaned_df = cleaned_df.dropna(subset=numeric_columns)
        
        # Calculate market value if not present
        if 'Market_Value' not in cleaned_df.columns:
            if 'Shares' in cleaned_df.columns and 'Price' in cleaned_df.columns:
                cleaned_df['Market_Value'] = cleaned_df['Shares'] * cleaned_df['Price']
        
        # Normalize weights if they don't sum to 1
        if 'Weight' in cleaned_df.columns:
            weight_sum = cleaned_df['Weight'].sum()
            if weight_sum > 0:
                cleaned_df['Weight'] = cleaned_df['Weight'] / weight_sum
        
        return cleaned_df
    
    def load_benchmark_data(self, benchmarks: List[str], start_date: str, end_date: str) -> Dict[str, pd.DataFrame]:
        """Load benchmark index data"""
        default_benchmarks = {
            '^GSPC': 'S&P 500',
            '^DJI': 'Dow Jones',
            '^IXIC': 'NASDAQ',
            '^RUT': 'Russell 2000',
            '^VIX': 'Volatility Index'
        }
        
        benchmark_data = {}
        
        for benchmark in benchmarks:
            try:
                ticker = yf.Ticker(benchmark)
                data = ticker.history(start=start_date, end=end_date)
                
                if not data.empty:
                    benchmark_data[benchmark] = data
                    benchmark_data[f"{benchmark}_name"] = default_benchmarks.get(benchmark, benchmark)
            
            except Exception as e:
                st.warning(f"Could not load benchmark {benchmark}: {e}")
                continue
        
        return benchmark_data
    
    def calculate_returns(self, price_data: pd.DataFrame, method: str = 'simple') -> pd.Series:
        """Calculate returns from price data"""
        if price_data.empty:
            return pd.Series()
        
        prices = price_data['Close'] if 'Close' in price_data.columns else price_data.iloc[:, 0]
        
        if method == 'simple':
            returns = prices.pct_change().dropna()
        elif method == 'log':
            returns = np.log(prices / prices.shift(1)).dropna()
        else:
            raise ValueError("Method must be 'simple' or 'log'")
        
        return returns
    
    def align_data(self, data_dict: Dict[str, pd.DataFrame], 
                   date_column: Optional[str] = None) -> Dict[str, pd.DataFrame]:
        """Align multiple time series to common date range"""
        if not data_dict:
            return {}
        
        # Find common date range
        all_indices = []
        for df in data_dict.values():
            if isinstance(df, pd.DataFrame) and not df.empty:
                all_indices.append(df.index)
        
        if not all_indices:
            return data_dict
        
        # Find intersection of all date ranges
        common_index = all_indices[0]
        for idx in all_indices[1:]:
            common_index = common_index.intersection(idx)
        
        if common_index.empty:
            st.warning("No common dates found across datasets")
            return data_dict
        
        # Align all dataframes to common index
        aligned_data = {}
        for key, df in data_dict.items():
            if isinstance(df, pd.DataFrame) and not df.empty:
                aligned_data[key] = df.reindex(common_index)
            else:
                aligned_data[key] = df
        
        return aligned_data
    
    def get_data_summary(self, data_dict: Dict[str, pd.DataFrame]) -> Dict[str, Dict]:
        """Generate summary statistics for loaded data"""
        summary = {}
        
        for key, df in data_dict.items():
            if isinstance(df, pd.DataFrame) and not df.empty:
                summary[key] = {
                    'start_date': df.index.min().strftime('%Y-%m-%d') if hasattr(df.index.min(), 'strftime') else str(df.index.min()),
                    'end_date': df.index.max().strftime('%Y-%m-%d') if hasattr(df.index.max(), 'strftime') else str(df.index.max()),
                    'observations': len(df),
                    'columns': list(df.columns),
                    'missing_values': df.isnull().sum().sum(),
                    'data_quality': 'Good' if df.isnull().sum().sum() < len(df) * 0.05 else 'Poor'
                }
        
        return summary
    
    def export_data(self, data: Union[pd.DataFrame, Dict], filename: str, format: str = 'csv') -> bytes:
        """Export data to various formats"""
        if format.lower() == 'csv':
            if isinstance(data, pd.DataFrame):
                return data.to_csv().encode('utf-8')
            elif isinstance(data, dict):
                # Convert dict to DataFrame if possible
                try:
                    df = pd.DataFrame(data)
                    return df.to_csv().encode('utf-8')
                except:
                    # Export as JSON if can't convert to DataFrame
                    import json
                    return json.dumps(data, indent=2).encode('utf-8')
        
        elif format.lower() == 'excel':
            from io import BytesIO
            buffer = BytesIO()
            
            if isinstance(data, pd.DataFrame):
                data.to_excel(buffer, index=True)
            elif isinstance(data, dict) and all(isinstance(v, pd.DataFrame) for v in data.values()):
                with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
                    for sheet_name, df in data.items():
                        df.to_excel(writer, sheet_name=sheet_name[:31], index=True)  # Excel sheet name limit
            
            buffer.seek(0)
            return buffer.getvalue()
        
        elif format.lower() == 'json':
            import json
            if isinstance(data, pd.DataFrame):
                return data.to_json(orient='records', indent=2).encode('utf-8')
            elif isinstance(data, dict):
                return json.dumps(data, indent=2, default=str).encode('utf-8')
        
        else:
            raise ValueError(f"Unsupported export format: {format}")

# Global instance for easy import
data_loader = DataLoader()

# Utility functions for common data operations
def load_portfolio_from_csv(file_path: str) -> pd.DataFrame:
    """Load portfolio data from CSV file"""
    try:
        df = pd.read_csv(file_path)
        return data_loader.clean_portfolio_data(df)
    except Exception as e:
        st.error(f"Error loading portfolio from CSV: {e}")
        return pd.DataFrame()

def get_risk_free_rate(source: str = 'fred') -> float:
    """Get current risk-free rate (simplified implementation)"""
    # In a production environment, this would connect to FRED API or similar
    # For now, return a default rate
    return 0.025  # 2.5% default

def calculate_sharpe_ratio(returns: pd.Series, risk_free_rate: float = None) -> float:
    """Calculate Sharpe ratio for return series"""
    if returns.empty:
        return 0.0
    
    if risk_free_rate is None:
        risk_free_rate = get_risk_free_rate()
    
    excess_returns = returns - risk_free_rate / 252  # Daily risk-free rate
    
    if excess_returns.std() == 0:
        return 0.0
    
    return excess_returns.mean() / excess_returns.std() * np.sqrt(252)  # Annualized

def calculate_max_drawdown(price_series: pd.Series) -> float:
    """Calculate maximum drawdown from price series"""
    if price_series.empty:
        return 0.0
    
    cumulative = (1 + price_series.pct_change()).cumprod()
    running_max = cumulative.expanding().max()
    drawdowns = (cumulative - running_max) / running_max
    
    return drawdowns.min()

def validate_date_range(start_date: str, end_date: str) -> Tuple[bool, str]:
    """Validate date range for data loading"""
    try:
        start = pd.to_datetime(start_date)
        end = pd.to_datetime(end_date)
        
        if start >= end:
            return False, "Start date must be before end date"
        
        if start < pd.to_datetime('1900-01-01'):
            return False, "Start date is too early"
        
        if end > pd.to_datetime('today'):
            return False, "End date cannot be in the future"
        
        # Check if date range is too short
        if (end - start).days < 30:
            return False, "Date range should be at least 30 days"
        
        return True, "Valid date range"
    
    except Exception as e:
        return False, f"Invalid date format: {e}"
