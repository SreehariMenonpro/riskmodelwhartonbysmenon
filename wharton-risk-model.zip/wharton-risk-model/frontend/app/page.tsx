"use client"
import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function RiskAnalysisApp() {
  const [ticker, setTicker] = useState("");
  const [data, setData] = useState<any>(null);

  const fetchData = async () => {
    const res = await fetch(`http://127.0.0.1:8000/price/${ticker}`);
    const json = await res.json();
    setData(json);
  };

  return (
    <div className="p-6 grid gap-6">
      <Card>
        <CardContent className="p-4">
          <div className="flex space-x-4">
            <Input placeholder="Ticker" value={ticker} onChange={(e) => setTicker(e.target.value)} />
            <Button onClick={fetchData}>Fetch</Button>
          </div>
        </CardContent>
      </Card>

      {data && (
        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-bold mb-2">{data.ticker} Risk Report</h2>
            <p>Last Price: ${data.last_price.toFixed(2)}</p>
            <p>Historical VaR (95%): {data.VaR_Historical.toFixed(4)}</p>
            <p>Parametric VaR: {data.VaR_Parametric.toFixed(4)}</p>

            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={data.dates.map((d: string, i: number) => ({ date: d, return: data.returns[i] }))}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" hide />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="return" stroke="#8884d8" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
