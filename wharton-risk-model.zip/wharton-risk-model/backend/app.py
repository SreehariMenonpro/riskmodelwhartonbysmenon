from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import yfinance as yf
import numpy as np
import pandas as pd

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/price/{ticker}")
def get_price(ticker: str):
    data = yf.download(ticker, period="1y")
    data = data["Adj Close"]
    returns = data.pct_change().dropna()

    # VaR
    var_95 = np.percentile(returns, 5)  
    param_var = -returns.mean() + 1.65 * returns.std()

    return {
        "ticker": ticker,
        "last_price": float(data.iloc[-1]),
        "returns": returns.tolist(),
        "dates": [str(x) for x in returns.index],
        "VaR_Historical": float(var_95),
        "VaR_Parametric": float(param_var),
    }

@app.get("/altman")
def altman(x1: float, x2: float, x3: float, x4: float, x5: float):
    z = 1.2*x1 + 1.4*x2 + 3.3*x3 + 0.6*x4 + 1.0*x5
    risk = "Safe" if z > 2.99 else "Distress" if z < 1.81 else "Grey Zone"
    return {"ZScore": z, "Risk": risk}

@app.get("/sizing")
def sizing(volatility: float, target_vol: float = 0.02):
    multiplier = target_vol / volatility if volatility > 0 else 0
    return {"volatility": volatility, "target_vol": target_vol, "sizing_multiplier": multiplier}
