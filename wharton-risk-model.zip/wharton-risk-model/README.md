# Wharton Risk Analysis Model

📊 A complete risk analysis toolkit for portfolio management, built for the Wharton Investment Competition.

## Features
- ✅ Live stock data (Yahoo Finance API)
- 📉 Value at Risk (VaR) – Historical & Parametric
- 🏦 Altman Z-Score for bankruptcy prediction
- ⚡ Volatility sizing for position management
- 🔥 Scenario shocks (e.g., 2008 crash simulation)

## Tech Stack
- Backend: Python (FastAPI, yfinance, numpy, pandas)
- Frontend: Next.js (React, Recharts, TailwindCSS)

## Run Locally
```bash
# Backend
cd backend
pip install -r requirements.txt
uvicorn app:app --reload --port 8000

# Frontend
cd frontend
npm install
npm run dev
```
